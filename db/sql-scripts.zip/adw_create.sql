SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE `auxLakesWithDepths` (
  `WaterBodyID` DOUBLE(15, 5) NULL,
  `WaterBodyName` VARCHAR(40) NULL,
  `DrainageCd` VARCHAR(17) NULL,
  `WaterBodyTypeCd` VARCHAR(4) NULL,
  `StartRouteMeas` DOUBLE(15, 5) NULL,
  `EndRouteMeas` DOUBLE(15, 5) NULL,
  INDEX `WATER_ID` (`WaterBodyID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `auxLakesWithSurveys` (
  `WaterBodyID` DOUBLE(15, 5) NULL,
  `WaterBodyName` VARCHAR(40) NULL,
  `DrainageCd` VARCHAR(17) NULL,
  `WaterBodyTypeCd` VARCHAR(4) NULL,
  `StartRouteMeas` DOUBLE(15, 5) NULL,
  `EndRouteMeas` DOUBLE(15, 5) NULL,
  INDEX `WATER_ID` (`WaterBodyID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `auxStockedWaters` (
  `WaterBodyID` DOUBLE(15, 5) NULL,
  `WaterBodyName` VARCHAR(50) NULL,
  `DrainageCd` VARCHAR(17) NULL,
  `WaterBodyTypeCd` VARCHAR(4) NULL,
  `StartRouteMeas` DOUBLE(15, 5) NULL,
  `EndRouteMeas` DOUBLE(15, 5) NULL,
  INDEX `WATERID` (`WaterBodyID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `auxStreamsWithSurveys` (
  `RIVER_SYS` SMALLINT(5) NULL,
  `WaterBodyID` DOUBLE(15, 5) NULL,
  `WaterBodyName` VARCHAR(40) NULL,
  `DrainageCd` VARCHAR(17) NULL,
  `STARTPOINT` VARCHAR(50) NULL,
  `ENDPOINT` VARCHAR(50) NULL,
  `StreamLength_km` DOUBLE(15, 5) NULL,
  `StartRouteMeas` DOUBLE(15, 5) NULL,
  `EndRouteMeas` DOUBLE(15, 5) NULL,
  INDEX `WATER_ID` (`WaterBodyID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `auxUserDBElectrofishingFopEstimate` (
  `EFPopulationEstimateID` INT(10) NOT NULL AUTO_INCREMENT,
  `oldEFPopulationEstimateID` INT(10) NULL,
  `EFDataID` INT(10) NULL,
  `TempDataID` INT(10) NULL,
  `oldEFDataID` DOUBLE(15, 5) NULL,
  `EFMRDataID` INT(10) NULL,
  `EFDataInd` TINYINT(1) NOT NULL DEFAULT 0,
  `AquaticActivityID` INT(10) NULL,
  `OLDAquaticActivityID` DOUBLE(15, 5) NULL,
  `Formula` VARCHAR(26) NULL,
  `FishSpeciesCd` VARCHAR(2) NULL,
  `FishAgeClass` VARCHAR(10) NULL,
  `RelativeSizeClass` VARCHAR(10) NULL,
  `AveForkLength_cm` DOUBLE(15, 5) NULL,
  `AveWeight_gm` DOUBLE(15, 5) NULL,
  `PopulationParameter` VARCHAR(20) NULL,
  `PopulationEstimate` DOUBLE(15, 5) NULL,
  `AutoCalculatedInd` TINYINT(1) NOT NULL DEFAULT 0,
  `Comments` VARCHAR(100) NULL,
  PRIMARY KEY (`EFPopulationEstimateID`),
  INDEX `AquaticActivityID` (`AquaticActivityID`),
  INDEX `EFASSMT_ID` (`OLDAquaticActivityID`),
  INDEX `EFDATA_ID` (`oldEFDataID`),
  INDEX `EFDataID` (`EFDataID`),
  INDEX `EFPopulationEstimateID` (`oldEFPopulationEstimateID`),
  INDEX `EFPopulationEstimateID1` (`EFPopulationEstimateID`),
  INDEX `TempEFDataID` (`TempDataID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `auxUSERDBNonRestrictedActivityIDs` (
  `AgencyCd` VARCHAR(4) NULL,
  `AquaticActivityID` INT(10) NULL,
  `AquaticActivityCd` SMALLINT(5) NULL,
  `AquaticActivity` VARCHAR(50) NULL,
  `AquaticActivityStartDate` VARCHAR(10) NULL
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `auxUserDBSelectedActivities` (
  `AquaticActivityID` INT(10) NULL,
  `DrainageCd` VARCHAR(17) NULL
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `auxUserDBSelectedSites` (
  `AquaticSiteUseID` INT(10) NOT NULL AUTO_INCREMENT,
  `AquaticSiteID` INT(10) NULL,
  `AquaticActivityCd` SMALLINT(5) NULL,
  `AgencyCd` VARCHAR(4) NULL,
  `DrainageCd` VARCHAR(17) NULL,
  PRIMARY KEY (`AquaticSiteUseID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `auxUserDBSelectedSiteUse` (
  `AquaticSiteUseID` INT(10) NOT NULL AUTO_INCREMENT,
  `AquaticSiteID` INT(10) NULL,
  `AquaticActivityCd` SMALLINT(5) NULL,
  `AgencyCd` VARCHAR(4) NULL,
  `DrainageCd` VARCHAR(17) NULL,
  PRIMARY KEY (`AquaticSiteUseID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdAgency` (
  `AgencyCd` VARCHAR(5) NOT NULL,
  `Agency` VARCHAR(60) NULL,
  `AgencyType` VARCHAR(4) NULL,
  `DataRulesInd` VARCHAR(1) NULL,
  PRIMARY KEY (`AgencyCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdAquaticActivity` (
  `AquaticActivityCd` SMALLINT(5) NOT NULL AUTO_INCREMENT,
  `AquaticActivity` VARCHAR(50) NULL,
  `AquaticActivityCategory` VARCHAR(30) NULL,
  `Duration` VARCHAR(20) NULL,
  PRIMARY KEY (`AquaticActivityCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdAquaticActivityMethod` (
  `AquaticMethodCd` SMALLINT(5) NOT NULL AUTO_INCREMENT,
  `AquaticActivityCd` SMALLINT(5) NULL,
  `AquaticMethod` VARCHAR(30) NULL,
  PRIMARY KEY (`AquaticMethodCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdCountyParish` (
  `CountyParishID` INT(10) NOT NULL AUTO_INCREMENT,
  `OldCountyCd` VARCHAR(10) NULL,
  `NewCountyCd` VARCHAR(11) NULL,
  `County` VARCHAR(17) NULL,
  `OldParishCd` VARCHAR(10) NULL,
  `NewParishCd` VARCHAR(12) NULL,
  `Parish` VARCHAR(22) NULL,
  `OldCountyParishCd` VARCHAR(6) NULL,
  `NewCountyParishCd` VARCHAR(7) NULL,
  PRIMARY KEY (`CountyParishID`),
  INDEX `CountyParishID` (`CountyParishID`),
  INDEX `NewCountyCd` (`NewCountyCd`),
  INDEX `NewParishCd` (`NewParishCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdEnvironmentalObservations` (
  `ObservationID` INT(10) NOT NULL AUTO_INCREMENT,
  `ObservationCategory` VARCHAR(40) NULL,
  `ObservationGroup` VARCHAR(50) NULL,
  `Observation` VARCHAR(50) NULL,
  PRIMARY KEY (`ObservationID`),
  INDEX `ObservationID` (`ObservationID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdFishAgeClass` (
  `FishAgeClass` VARCHAR(25) NOT NULL,
  `FishAgeClassCategory` VARCHAR(20) NULL,
  `StockingInd` TINYINT(1) NOT NULL DEFAULT 0,
  `ElectrofishInd` TINYINT(1) NOT NULL DEFAULT 0,
  `FishCountInd` TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`FishAgeClass`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdFishMark` (
  `FishMarkCd` INT(10) NOT NULL,
  `FishMark` VARCHAR(50) NULL,
  PRIMARY KEY (`FishMarkCd`),
  INDEX `Fin Status Code` (`FishMarkCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdFishMortalityCause` (
  `MortalityCauseCd` INT(10) NOT NULL,
  `CauseOfMortality` VARCHAR(50) NULL,
  PRIMARY KEY (`MortalityCauseCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdFishParasiteClass` (
  `ParasiteClassCd` VARCHAR(4) NOT NULL,
  `ParasiteClass` VARCHAR(20) NULL,
  `Location` VARCHAR(24) NULL,
  PRIMARY KEY (`ParasiteClassCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdFishPopulationFormula` (
  `FormulaCd` INT(10) NOT NULL AUTO_INCREMENT,
  `Formula` VARCHAR(20) NULL,
  PRIMARY KEY (`FormulaCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdFishPopulationParameter` (
  `PopulationParameter` VARCHAR(20) NULL
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdFishSpecies` (
  `FishSpeciesCd` VARCHAR(2) NOT NULL,
  `FishSpecies` VARCHAR(30) NULL,
  `StockedInd` TINYINT(1) NOT NULL DEFAULT 0,
  `ElectrofishInd` TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`FishSpeciesCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdFishStatus` (
  `FishStatusCd` VARCHAR(10) NOT NULL,
  `FishStatus` VARCHAR(50) NULL,
  `FishStatusType` VARCHAR(20) NULL,
  PRIMARY KEY (`FishStatusCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdFishStomachContent` (
  `StomachContentCd` INT(10) NOT NULL AUTO_INCREMENT,
  `StomachContent` VARCHAR(20) NULL,
  PRIMARY KEY (`StomachContentCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdHabitatUnitComment` (
  `CommentCd` VARCHAR(2) NOT NULL,
  `Comment` VARCHAR(30) NULL,
  PRIMARY KEY (`CommentCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdInstrument` (
  `InstrumentCd` INT(10) NOT NULL AUTO_INCREMENT,
  `Instrument` VARCHAR(50) NULL,
  `Instrument_Category` VARCHAR(50) NULL,
  PRIMARY KEY (`InstrumentCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdMeasureInstrument` (
  `MeasureInstrumentCd` INT(10) NOT NULL AUTO_INCREMENT,
  `OandMCd` INT(10) NULL,
  `InstrumentCd` INT(10) NULL,
  PRIMARY KEY (`MeasureInstrumentCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdMeasureUnit` (
  `MeasureUnitCd` INT(10) NOT NULL AUTO_INCREMENT,
  `OandMCd` INT(10) NULL,
  `UnitofMeasureCd` INT(10) NULL,
  PRIMARY KEY (`MeasureUnitCd`),
  INDEX `cdMeasureUnitOandMCd` (`OandMCd`),
  INDEX `cdMeasureUnitUnitofMeasureCd` (`UnitofMeasureCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdOandM` (
  `OandMCd` INT(10) NOT NULL AUTO_INCREMENT,
  `OandM_Type` VARCHAR(16) NULL,
  `OandM_Category` VARCHAR(40) NULL,
  `OandM_Group` VARCHAR(50) NULL,
  `OandM_Parameter` VARCHAR(50) NULL,
  `OandM_ParameterCd` VARCHAR(30) NULL,
  `OandM_ValuesInd` TINYINT(1) NOT NULL DEFAULT 0,
  `OandM_DetailsInd` TINYINT(1) NOT NULL DEFAULT 0,
  `FishPassageInd` TINYINT(1) NOT NULL DEFAULT 0,
  `BankInd` TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`OandMCd`),
  INDEX `ObservationID` (`OandMCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdOandMValues` (
  `OandMValuesCd` INT(10) NOT NULL AUTO_INCREMENT,
  `OandMCd` INT(10) NULL,
  `Value` VARCHAR(20) NULL,
  PRIMARY KEY (`OandMValuesCd`),
  INDEX `O&M_ID` (`OandMCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdSampleCollectionMethod` (
  `SampleMethodCd` INT(10) NOT NULL AUTO_INCREMENT,
  `SampleMethod` VARCHAR(30) NULL,
  `Description` VARCHAR(255) NULL,
  PRIMARY KEY (`SampleMethodCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdSampleGear` (
  `SampleGearCd` INT(10) NOT NULL AUTO_INCREMENT,
  `SampleGear` VARCHAR(20) NULL,
  PRIMARY KEY (`SampleGearCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdSex` (
  `SexCd` VARCHAR(1) NOT NULL,
  `Sex` VARCHAR(10) NULL,
  PRIMARY KEY (`SexCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdStreamChannelType` (
  `ChannelCd` VARCHAR(1) NOT NULL,
  `ChannelType` VARCHAR(6) NULL,
  PRIMARY KEY (`ChannelCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdStreamEmbeddedness` (
  `EmbeddedCd` VARCHAR(1) NOT NULL,
  `Embeddedness` VARCHAR(10) NULL,
  PRIMARY KEY (`EmbeddedCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdStreamType` (
  `StreamTypeCd` VARCHAR(2) NOT NULL,
  `StreamType` VARCHAR(24) NULL,
  `StreamTypeGroup` VARCHAR(6) NULL,
  PRIMARY KEY (`StreamTypeCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdUnitofMeasure` (
  `UnitofMeasureCd` INT(10) NOT NULL AUTO_INCREMENT,
  `UnitofMeasure` VARCHAR(50) NULL,
  `UnitofMeasureAbv` VARCHAR(10) NULL,
  PRIMARY KEY (`UnitofMeasureCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdWaterChemistryQualifier` (
  `QualifierCd` VARCHAR(4) NOT NULL,
  `Qualifier` VARCHAR(100) NULL,
  PRIMARY KEY (`QualifierCd`),
  INDEX `cdWaterChemistryQualifierQualif` (`QualifierCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdWaterParameter` (
  `WaterParameterCd` INT(10) NOT NULL,
  `WaterParameter` VARCHAR(50) NULL,
  PRIMARY KEY (`WaterParameterCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdWaterSource` (
  `WaterSourceCd` VARCHAR(4) NOT NULL,
  `WaterSource` VARCHAR(20) NULL,
  `WaterSourceType` VARCHAR(20) NULL,
  PRIMARY KEY (`WaterSourceCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `cdWaterSourceType` (
  `WaterSourceType` VARCHAR(30) NOT NULL,
  PRIMARY KEY (`WaterSourceType`),
  INDEX `cdWaterSourceTypeWaterSourceType` (`WaterSourceType`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `rpttblBasinOrderingScheme` (
  `Level1No` VARCHAR(2) NOT NULL,
  `Level1Name` VARCHAR(40) NULL,
  `OceanName` VARCHAR(20) NULL,
  `Level1Area_km2` DOUBLE(15, 5) NULL,
  `Level1Area_Percent` DOUBLE(15, 5) NULL,
  `Order` INT(10) NULL,
  PRIMARY KEY (`Level1No`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblAnglingLease` (
  `RegulatedWaterID` INT(10) NOT NULL,
  `LeaseNo` SMALLINT(5) NULL,
  `LeaseDesc` VARCHAR(254) NULL,
  `StreamLength_km` DOUBLE(15, 5) NULL,
  `NoRodsPerDay` SMALLINT(5) NULL,
  `NoRodsPerYear` VARCHAR(24) NULL,
  `ExpiryYear` VARCHAR(4) NULL,
  `LodgeName` VARCHAR(20) NULL,
  `Lessee` VARCHAR(45) NULL,
  `LesseeAddress1` VARCHAR(30) NULL,
  `LesseeAddress2` VARCHAR(20) NULL,
  `LesseeCity` VARCHAR(20) NULL,
  `LesseProv` VARCHAR(2) NULL,
  `LesseePostalCd` VARCHAR(7) NULL,
  `Contact1` VARCHAR(20) NULL,
  `Contact1Title` VARCHAR(20) NULL,
  `Contact1Dept` VARCHAR(25) NULL,
  `Contact1Phone` VARCHAR(14) NULL,
  `Contact1Fax` VARCHAR(14) NULL,
  `Contact2` VARCHAR(24) NULL,
  `Contact2Title` VARCHAR(20) NULL,
  `Contact2Dept` VARCHAR(20) NULL,
  `Contact2Phone` VARCHAR(14) NULL,
  `Contact2Fax` VARCHAR(14) NULL,
  `Manager` VARCHAR(21) NULL,
  `ManagerPhone` VARCHAR(14) NULL,
  PRIMARY KEY (`RegulatedWaterID`),
  INDEX `{D3655704-EBA1-41D7-8CCB-412119` (`RegulatedWaterID`),
  INDEX `LEASE_ID` (`LeaseNo`),
  INDEX `RegulatedWatersID` (`RegulatedWaterID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblAnglingLicenseSales` (
  `LicenseSalesID` INT(10) NOT NULL AUTO_INCREMENT,
  `LicenseCd` INT(10) NULL,
  `Residence` VARCHAR(255) NULL,
  `LicenseType` VARCHAR(255) NULL,
  `LicenseClass` VARCHAR(255) NULL,
  `LicenseDesc` VARCHAR(255) NULL,
  `Year` INT(10) NULL,
  `NoSold` INT(10) NULL,
  PRIMARY KEY (`LicenseSalesID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblAquaticActivity` (
  `AquaticActivityID` INT(10) NOT NULL AUTO_INCREMENT,
  `TempAquaticActivityID` INT(10) NULL,
  `Project` VARCHAR(100) NULL,
  `PermitNo` VARCHAR(20) NULL,
  `AquaticProgramID` INT(10) NULL,
  `AquaticActivityCd` SMALLINT(5) NULL,
  `AquaticMethodCd` SMALLINT(5) NULL,
  `oldAquaticSiteID` INT(10) NULL,
  `AquaticSiteID` INT(10) NULL,
  `AquaticActivityStartDate` VARCHAR(10) NULL,
  `AquaticActivityEndDate` VARCHAR(10) NULL,
  `AquaticActivityStartTime` VARCHAR(6) NULL,
  `AquaticActivityEndTime` VARCHAR(6) NULL,
  `Year` VARCHAR(4) NULL,
  `AgencyCd` VARCHAR(4) NULL,
  `Agency2Cd` VARCHAR(4) NULL,
  `Agency2Contact` VARCHAR(50) NULL,
  `AquaticActivityLeader` VARCHAR(50) NULL,
  `Crew` VARCHAR(50) NULL,
  `WeatherConditions` VARCHAR(50) NULL,
  `WaterTemp_C` DOUBLE(7, 2) NULL,
  `AirTemp_C` DOUBLE(7, 2) NULL,
  `WaterLevel` VARCHAR(6) NULL,
  `WaterLevel_cm` VARCHAR(50) NULL,
  `WaterLevel_AM_cm` VARCHAR(50) NULL,
  `WaterLevel_PM_cm` VARCHAR(50) NULL,
  `Siltation` VARCHAR(50) NULL,
  `PrimaryActivityInd` TINYINT(1) NOT NULL DEFAULT 0,
  `Comments` VARCHAR(250) NULL,
  `DateEntered` DATETIME NULL,
  `IncorporatedInd` TINYINT(1) NOT NULL DEFAULT 0,
  `DateTransferred` DATETIME NULL,
  PRIMARY KEY (`AquaticActivityID`),
  INDEX `{33D6B2E4-F11A-47D1-BFE4-EE52E8` (`AquaticSiteID`),
  INDEX `{66945D2F-F4E9-46B3-B601-8B4AC0` (`AquaticActivityCd`),
  INDEX `{86A93E88-27E1-4293-8F8F-51509C` (`AquaticProgramID`),
  INDEX `{D79D562C-FC0D-4C7B-AF79-95EFDA` (`Agency2Cd`),
  INDEX `{DBF31B0D-A36E-42EC-A246-E33178` (`AgencyCd`),
  INDEX `{FFCC8125-2385-49D8-9E05-364C40` (`Agency2Cd`),
  INDEX `AquaticActivityID1` (`AquaticActivityID`),
  INDEX `AquaticProgramID` (`AquaticProgramID`),
  INDEX `FisheriesSiteID` (`AquaticSiteID`),
  INDEX `OldAquaticActivityID` (`TempAquaticActivityID`),
  INDEX `oldAquaticSiteID` (`oldAquaticSiteID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblAquaticProgram` (
  `AquaticProgramID` INT(10) NOT NULL,
  `AquaticProgramName` VARCHAR(30) NULL,
  `AquaticProgramPurpose` VARCHAR(150) NULL,
  `AquaticProgramStartDate` DATETIME NULL,
  `AquaticProgramEndDate` DATETIME NULL,
  `AgencyCd` VARCHAR(4) NULL,
  `AquaticProgramLeader` VARCHAR(50) NULL,
  PRIMARY KEY (`AquaticProgramID`),
  INDEX `{D2FEB2BB-F414-4F7D-8613-ACB906` (`AgencyCd`),
  INDEX `AquaticProgramID` (`AquaticProgramID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblAquaticSite` (
  `AquaticSiteID` INT(10) NOT NULL AUTO_INCREMENT,
  `oldAquaticSiteID` INT(10) NULL,
  `RiverSystemID` SMALLINT(5) NULL,
  `WaterBodyID` INT(10) NULL,
  `WaterBodyName` VARCHAR(50) NULL,
  `AquaticSiteName` VARCHAR(100) NULL,
  `AquaticSiteDesc` VARCHAR(250) NULL,
  `HabitatDesc` VARCHAR(50) NULL,
  `ReachNo` INT(10) NULL,
  `StartDesc` VARCHAR(100) NULL,
  `EndDesc` VARCHAR(100) NULL,
  `StartRouteMeas` DOUBLE(15, 5) NULL,
  `EndRouteMeas` DOUBLE(15, 5) NULL,
  `SiteType` VARCHAR(20) NULL,
  `SpecificSiteInd` VARCHAR(1) NULL,
  `GeoReferencedInd` VARCHAR(1) NULL,
  `DateEntered` DATETIME NULL,
  `IncorporatedInd` TINYINT(1) NOT NULL DEFAULT 0,
  `CoordinateSource` VARCHAR(50) NULL,
  `CoordinateSystem` VARCHAR(50) NULL,
  `XCoordinate` VARCHAR(50) NULL,
  `YCoordinate` VARCHAR(50) NULL,
  `CoordinateUnits` VARCHAR(50) NULL,
  `Comments` VARCHAR(150) NULL,
  PRIMARY KEY (`AquaticSiteID`),
  INDEX `{047A49A9-3B29-47B9-B429-4EBFC4` (`WaterBodyID`),
  INDEX `{A85D1309-1E35-4A86-8D76-67637B` (`RiverSystemID`),
  INDEX `AssmtSiteID` (`AquaticSiteID`),
  INDEX `oldAquaticSiteID` (`oldAquaticSiteID`),
  INDEX `RiverSystemID` (`RiverSystemID`),
  INDEX `WaterBodyID` (`WaterBodyID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblAquaticSiteAgencyUse` (
  `AquaticSiteUseID` INT(10) NOT NULL AUTO_INCREMENT,
  `AquaticSiteID` INT(10) NULL,
  `AquaticActivityCd` SMALLINT(5) NULL,
  `AquaticSiteType` VARCHAR(30) NULL,
  `AgencyCd` VARCHAR(4) NULL,
  `AgencySiteID` VARCHAR(16) NULL,
  `StartYear` VARCHAR(4) NULL,
  `EndYear` VARCHAR(4) NULL,
  `YearsActive` VARCHAR(20) NULL,
  `DateEntered` DATETIME NULL,
  `IncorporatedInd` TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`AquaticSiteUseID`),
  INDEX `{AE11D8D8-9E33-4740-BC97-E80094` (`AquaticSiteID`),
  INDEX `AgencySiteID` (`AgencySiteID`),
  INDEX `AssmtSiteID` (`AquaticSiteUseID`),
  INDEX `WaterBodyID` (`AquaticSiteID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblBacterialAnalysis` (
  `BacterialAnalysisID` INT(10) NOT NULL AUTO_INCREMENT,
  `AquaticActivityID` INT(10) NULL,
  `TempAquaticActivityID` INT(10) NULL,
  `DOE_LabNo` VARCHAR(8) NULL,
  `DOE_FieldNo` VARCHAR(10) NULL,
  `SampleDepth_m` DOUBLE(15, 5) NULL,
  `WaterTemp_C` DOUBLE(15, 5) NULL,
  `QualifierA` VARCHAR(2) NULL,
  `FaecalColiformCount_A` DOUBLE(15, 5) NULL,
  `QualifierB` VARCHAR(2) NULL,
  `FaecalColiformCount_B` DOUBLE(15, 5) NULL,
  `L_TotalColiforms` VARCHAR(1) NULL,
  `TotalColiforms` INT(10) NULL,
  `Ecoli` DOUBLE(15, 5) NULL,
  PRIMARY KEY (`BacterialAnalysisID`),
  INDEX `{B0CA8FCD-3C0D-4472-B2A9-904822` (`AquaticActivityID`),
  INDEX `AquaticActivityID` (`AquaticActivityID`),
  INDEX `BacterialAnalysisID` (`BacterialAnalysisID`),
  INDEX `OldAquaticActivityID` (`TempAquaticActivityID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblBroodstockCollection` (
  `AquaticActivityID` INT(10) NOT NULL,
  `TempAquaticActivityID` INT(10) NULL,
  `Wild_M_MSW` DOUBLE(15, 5) NULL,
  `Wild_F_MSW` DOUBLE(15, 5) NULL,
  `Clipped_M_MSW` DOUBLE(15, 5) NULL,
  `Clipped_F_MSW` DOUBLE(15, 5) NULL,
  `Total_M_MSW` DOUBLE(15, 5) NULL,
  `Total_F_MSW` DOUBLE(15, 5) NULL,
  `Total_MSW` DOUBLE(15, 5) NULL,
  `Wild_M_Grilse` DOUBLE(15, 5) NULL,
  `Wild_F_Grilse` DOUBLE(15, 5) NULL,
  `Clipped_M_Grilse` DOUBLE(15, 5) NULL,
  `Clipped_F_Grilse` DOUBLE(15, 5) NULL,
  `Total_M_Grilse` DOUBLE(15, 5) NULL,
  `Total_F_Grilse` DOUBLE(15, 5) NULL,
  `Total_Grilse` DOUBLE(15, 5) NULL,
  `Total_F_ASalmon` DOUBLE(15, 5) NULL,
  `Total_M_ASalmon` DOUBLE(15, 5) NULL,
  `Total_ASalmon` DOUBLE(15, 5) NULL,
  `Comments` VARCHAR(250) NULL,
  PRIMARY KEY (`AquaticActivityID`),
  INDEX `{980D252C-07FE-480B-9235-EA23BD` (`AquaticActivityID`),
  INDEX `AquaticActivityID` (`TempAquaticActivityID`),
  INDEX `AquaticActivityID1` (`AquaticActivityID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblCrownReserve` (
  `RegulatedWaterID` INT(10) NOT NULL,
  `AnglingFishSpecies` VARCHAR(20) NULL,
  `StreamLength_km` DOUBLE(15, 5) NULL,
  `NoPools` SMALLINT(5) NULL,
  `NoDays` SMALLINT(5) NULL,
  `MaxRodPerDay` SMALLINT(5) NULL,
  `AccommodationsInd` VARCHAR(1) NULL,
  `StartYear` VARCHAR(10) NULL,
  `EndYear` VARCHAR(10) NULL,
  `ActiveInd` VARCHAR(1) NULL,
  PRIMARY KEY (`RegulatedWaterID`),
  INDEX `{2F73944A-EE45-4C58-B41D-F6542A` (`RegulatedWaterID`),
  INDEX `RegulatedWatersID` (`RegulatedWaterID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblDraingeUnit` (
  `DrainageCd` VARCHAR(17) NOT NULL,
  `Level1No` VARCHAR(2) NULL,
  `Level1Name` VARCHAR(40) NULL,
  `Level2No` VARCHAR(2) NULL,
  `Level2Name` VARCHAR(50) NULL,
  `Level3No` VARCHAR(2) NULL,
  `Level3Name` VARCHAR(50) NULL,
  `Level4No` VARCHAR(2) NULL,
  `Level4Name` VARCHAR(50) NULL,
  `Level5No` VARCHAR(2) NULL,
  `Level5Name` VARCHAR(50) NULL,
  `Level6No` VARCHAR(2) NULL,
  `Level6Name` VARCHAR(50) NULL,
  `UnitName` VARCHAR(55) NULL,
  `UnitType` VARCHAR(4) NULL,
  `BorderInd` VARCHAR(1) NULL,
  `StreamOrder` SMALLINT(5) NULL,
  `Area_ha` DOUBLE(15, 5) NULL,
  `Area_percent` DOUBLE(15, 5) NULL,
  PRIMARY KEY (`DrainageCd`),
  INDEX `{C26A40DF-1604-4BE7-BDBD-F8BC6C` (`Level1No`),
  INDEX `tblDraingeUnitsDrainageCd` (`DrainageCd`),
  INDEX `tblDraingeUnitsLevel1No` (`Level1No`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblElectrofishingData` (
  `EFDataID` INT(10) NOT NULL AUTO_INCREMENT,
  `oldEFDataID` DOUBLE(15, 5) NULL,
  `TempDataID` INT(10) NULL,
  `AquaticActivityID` INT(10) NULL,
  `TempAquaticActivityID` DOUBLE(15, 5) NULL,
  `FishSpeciesCd` VARCHAR(2) NULL,
  `FishAgeClass` VARCHAR(10) NULL,
  `RelativeSizeClass` VARCHAR(10) NULL,
  `AveWeight_gm` DOUBLE(15, 5) NULL,
  `AveForkLength_cm` DOUBLE(15, 5) NULL,
  `AveTotalLength_cm` DOUBLE(15, 5) NULL,
  `Sweep1NoFish` DOUBLE(15, 5) NULL,
  `Sweep1Time_s` DOUBLE(15, 5) NULL,
  `Sweep2NoFish` DOUBLE(15, 5) NULL,
  `Sweep2Time_s` DOUBLE(15, 5) NULL,
  `Sweep3NoFish` DOUBLE(15, 5) NULL,
  `Sweep3Time_s` DOUBLE(15, 5) NULL,
  `Sweep4NoFish` DOUBLE(15, 5) NULL,
  `Sweep4Time_s` DOUBLE(15, 5) NULL,
  `Sweep5NoFish` DOUBLE(15, 5) NULL,
  `Sweep5Time_s` DOUBLE(15, 5) NULL,
  `Sweep6NoFish` DOUBLE(15, 5) NULL,
  `Sweep6Time_s` DOUBLE(15, 5) NULL,
  `TotalNoSweeps` INT(10) NULL,
  `TotalNoFish` DOUBLE(15, 5) NULL,
  `PercentClipped` DOUBLE(15, 5) NULL,
  `Comments` VARCHAR(100) NULL,
  `DW_Comments` VARCHAR(100) NULL,
  PRIMARY KEY (`EFDataID`),
  INDEX `{196E57D0-3F38-43B2-B4E7-3A9546` (`AquaticActivityID`),
  INDEX `{3307D7AA-47A2-4D30-B30E-4596D1` (`FishSpeciesCd`),
  INDEX `{D2C885E2-CCEF-47E5-AF27-170490` (`FishAgeClass`),
  INDEX `AquaticActivityID` (`AquaticActivityID`),
  INDEX `EFASSMT_ID` (`TempAquaticActivityID`),
  INDEX `EFDATA_ID` (`oldEFDataID`),
  INDEX `EFDataID` (`EFDataID`),
  INDEX `TempEFDataID` (`TempDataID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblElectrofishingMarkRecaptureData` (
  `EFMRDataID` INT(10) NOT NULL AUTO_INCREMENT,
  `AquaticActivityID` INT(10) NULL,
  `TempAquaticActivityID` DOUBLE(15, 5) NULL,
  `TempDataID` INT(10) NULL,
  `RecaptureTime` SMALLINT(5) NULL,
  `FishSpeciesCd` VARCHAR(2) NULL,
  `FishAgeClass` VARCHAR(10) NULL,
  `AveWeight_gm` DOUBLE(15, 5) NULL,
  `AveForkLength_cm` DOUBLE(15, 5) NULL,
  `AveTotalLength_cm` DOUBLE(15, 5) NULL,
  `MarkCount` DOUBLE(15, 5) NULL,
  `MarkMarked` DOUBLE(15, 5) NULL,
  `MarkMorts` DOUBLE(15, 5) NULL,
  `RecaptureCount` DOUBLE(15, 5) NULL,
  `RecaptureUnmarked` DOUBLE(15, 5) NULL,
  `RecaptureMarked` DOUBLE(15, 5) NULL,
  `RecaptureMorts` DOUBLE(15, 5) NULL,
  `MarkEfficiency` DOUBLE(15, 5) NULL,
  `Comments` VARCHAR(100) NULL,
  `DW_Comments` VARCHAR(100) NULL,
  PRIMARY KEY (`EFMRDataID`),
  INDEX `{22F2CEBB-F47B-4837-8840-C009FB` (`FishAgeClass`),
  INDEX `{B2C296E5-A98F-454E-A7A0-2A3DFE` (`AquaticActivityID`),
  INDEX `{E1056899-F963-4116-855D-6F47EE` (`FishSpeciesCd`),
  INDEX `AquaticActivityID` (`AquaticActivityID`),
  INDEX `EFASSMT_ID` (`TempAquaticActivityID`),
  INDEX `EFDATA_ID` (`EFMRDataID`),
  INDEX `TempDataID` (`TempDataID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblElectrofishingMethodDetail` (
  `AquaticActivityDetailID` INT(10) NOT NULL AUTO_INCREMENT,
  `AquaticActivityID` INT(10) NULL,
  `TempAquaticActivityID` INT(10) NULL,
  `Device` VARCHAR(20) NULL,
  `SiteSetup` VARCHAR(6) NULL,
  `NoSweeps` SMALLINT(5) NULL,
  `StreamLength_m` DOUBLE(7, 2) NULL,
  `Area_m2` DOUBLE(7, 2) NULL,
  `Voltage` DOUBLE(15, 5) NULL,
  `Frequency_Hz` DOUBLE(15, 5) NULL,
  `DutyCycle` DOUBLE(15, 5) NULL,
  `POWSetting` DOUBLE(15, 5) NULL,
  PRIMARY KEY (`AquaticActivityDetailID`),
  INDEX `{974003F4-D516-4FAA-9C71-2FC24E` (`AquaticActivityID`),
  INDEX `AquaticActivityDetailsID` (`AquaticActivityDetailID`),
  INDEX `AquaticActivityID` (`AquaticActivityID`),
  INDEX `AssmtPrgrmID` (`TempAquaticActivityID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblElectrofishingPopulationEstimate` (
  `EFPopulationEstimateID` INT(10) NOT NULL AUTO_INCREMENT,
  `oldEFPopulationEstimateID` INT(10) NULL,
  `EFDataID` INT(10) NULL,
  `TempDataID` INT(10) NULL,
  `oldEFDataID` DOUBLE(15, 5) NULL,
  `EFMRDataID` INT(10) NULL,
  `EFDataInd` TINYINT(1) NOT NULL DEFAULT 0,
  `AquaticActivityID` INT(10) NULL,
  `TempAquaticActivityID` DOUBLE(15, 5) NULL,
  `Formula` VARCHAR(26) NULL,
  `FishSpeciesCd` VARCHAR(2) NULL,
  `FishAgeClass` VARCHAR(10) NULL,
  `RelativeSizeClass` VARCHAR(10) NULL,
  `AveForkLength_cm` DOUBLE(15, 5) NULL,
  `AveWeight_gm` DOUBLE(15, 5) NULL,
  `PopulationParameter` VARCHAR(20) NULL,
  `PopulationEstimate` DOUBLE(15, 5) NULL,
  `AutoCalculatedInd` TINYINT(1) NOT NULL DEFAULT 0,
  `Comments` VARCHAR(100) NULL,
  PRIMARY KEY (`EFPopulationEstimateID`),
  INDEX `{3054E6F5-67BE-4433-BA0D-203C0F` (`FishAgeClass`),
  INDEX `{619029C0-02D2-4149-BE10-808545` (`AquaticActivityID`),
  INDEX `{D6A691C5-AB3C-4A65-9711-F88235` (`FishSpeciesCd`),
  INDEX `AquaticActivityID` (`AquaticActivityID`),
  INDEX `EFASSMT_ID` (`TempAquaticActivityID`),
  INDEX `EFDATA_ID` (`oldEFDataID`),
  INDEX `EFDataID` (`EFDataID`),
  INDEX `EFPopulationEstimateID` (`oldEFPopulationEstimateID`),
  INDEX `EFPopulationEstimateID1` (`EFPopulationEstimateID`),
  INDEX `TempEFDataID` (`TempDataID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblEnvironmentalObservations` (
  `EnvObservationID` INT(10) NOT NULL AUTO_INCREMENT,
  `AquaticActivityID` INT(10) NULL,
  `ObservationGroup` VARCHAR(50) NULL,
  `Observation` VARCHAR(50) NULL,
  `ObservationSupp` VARCHAR(50) NULL,
  `PipeSize_cm` INT(10) NULL,
  `FishPassageObstructionInd` TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`EnvObservationID`),
  UNIQUE INDEX `EnvObservationID` (`EnvObservationID`),
  INDEX `AquaticActivityID` (`AquaticActivityID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblEnvironmentalPlanning` (
  `EnvPlanningID` INT(10) NOT NULL AUTO_INCREMENT,
  `AquaticActivityID` INT(10) NULL,
  `IssueCategory` VARCHAR(50) NULL,
  `Issue` VARCHAR(250) NULL,
  `ActionRequired` VARCHAR(250) NULL,
  `ActionTargetDate` DATETIME NULL,
  `ActionPriority` SMALLINT(5) NULL,
  `ActionCompletionDate` DATETIME NULL,
  `FollowUpRequired` TINYINT(1) NOT NULL DEFAULT 0,
  `FollowUpTargetDate` DATETIME NULL,
  `FollowUpCompletionDate` DATETIME NULL,
  PRIMARY KEY (`EnvPlanningID`),
  UNIQUE INDEX `EnvPlanningID` (`EnvPlanningID`),
  INDEX `AquaticActivityID` (`AquaticActivityID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblEnvironmentalSurveyFieldMeasures` (
  `FieldMeasureID` INT(10) NOT NULL AUTO_INCREMENT,
  `AquaticActivityID` INT(10) NULL,
  `StreamCover` VARCHAR(10) NULL,
  `BankStability` VARCHAR(20) NULL,
  `BankSlope_Rt` SMALLINT(5) NULL,
  `BankSlope_Lt` SMALLINT(5) NULL,
  `StreamType` VARCHAR(10) NULL,
  `StreamTypeSupp` VARCHAR(30) NULL,
  `SuspendedSilt` TINYINT(1) NOT NULL DEFAULT 0,
  `EmbeddedSub` TINYINT(1) NOT NULL DEFAULT 0,
  `AquaticPlants` TINYINT(1) NOT NULL DEFAULT 0,
  `Algae` TINYINT(1) NOT NULL DEFAULT 0,
  `Petroleum` TINYINT(1) NOT NULL DEFAULT 0,
  `Odor` TINYINT(1) NOT NULL DEFAULT 0,
  `Foam` TINYINT(1) NOT NULL DEFAULT 0,
  `DeadFish` TINYINT(1) NOT NULL DEFAULT 0,
  `Other` TINYINT(1) NOT NULL DEFAULT 0,
  `OtherSupp` VARCHAR(50) NULL,
  `Length_m` DOUBLE(7, 2) NULL,
  `AveWidth_m` DOUBLE(7, 2) NULL,
  `AveDepth_m` DOUBLE(7, 2) NULL,
  `Velocity_mpers` DOUBLE(7, 2) NULL,
  `WaterClarity` VARCHAR(16) NULL,
  `WaterColor` VARCHAR(10) NULL,
  `Weather_Past` VARCHAR(20) NULL,
  `Weather_Current` VARCHAR(20) NULL,
  `RZ_Lawn_Lt` SMALLINT(5) NULL,
  `RZ_Lawn_Rt` DOUBLE(7, 2) NULL,
  `RZ_RowCrop_Lt` SMALLINT(5) NULL,
  `RZ_RowCrop_Rt` SMALLINT(5) NULL,
  `RZ_ForageCrop_Lt` SMALLINT(5) NULL,
  `RZ_ForageCrop_Rt` SMALLINT(5) NULL,
  `RZ_Shrubs_Lt` SMALLINT(5) NULL,
  `RZ_Shrubs_Rt` SMALLINT(5) NULL,
  `RZ_Hardwood_Lt` SMALLINT(5) NULL,
  `RZ_Hardwood_Rt` SMALLINT(5) NULL,
  `RZ_Softwood_Lt` SMALLINT(5) NULL,
  `RZ_Softwood_Rt` SMALLINT(5) NULL,
  `RZ_Mixed_Lt` SMALLINT(5) NULL,
  `RZ_Mixed_Rt` SMALLINT(5) NULL,
  `RZ_Meadow_Lt` SMALLINT(5) NULL,
  `RZ_Meadow_Rt` SMALLINT(5) NULL,
  `RZ_Wetland_Lt` SMALLINT(5) NULL,
  `RZ_Wetland_Rt` SMALLINT(5) NULL,
  `RZ_Altered_Lt` SMALLINT(5) NULL,
  `RZ_Altered_Rt` SMALLINT(5) NULL,
  `ST_TimeofDay` VARCHAR(5) NULL,
  `ST_DissOxygen` DOUBLE(7, 2) NULL,
  `ST_AirTemp_C` DOUBLE(7, 2) NULL,
  `ST_WaterTemp_C` DOUBLE(7, 2) NULL,
  `ST_pH` DOUBLE(7, 2) NULL,
  `ST_Conductivity` DOUBLE(7, 2) NULL,
  `ST_Flow_cms` DOUBLE(7, 2) NULL,
  `ST_DELGFieldNo` VARCHAR(50) NULL,
  `GW1_TimeofDay` VARCHAR(5) NULL,
  `GW1_DissOxygen` DOUBLE(7, 2) NULL,
  `GW1_AirTemp_C` DOUBLE(7, 2) NULL,
  `GW1_WaterTemp_C` DOUBLE(7, 2) NULL,
  `GW1_pH` DOUBLE(7, 2) NULL,
  `GW1_Conductivity` DOUBLE(7, 2) NULL,
  `GW1_Flow_cms` DOUBLE(7, 2) NULL,
  `GW1_DELGFieldNo` VARCHAR(50) NULL,
  `GW2_TimeofDay` VARCHAR(5) NULL,
  `GW2_DissOxygen` DOUBLE(7, 2) NULL,
  `GW2_AirTemp_C` DOUBLE(7, 2) NULL,
  `GW2_WaterTemp_C` DOUBLE(7, 2) NULL,
  `GW2_pH` DOUBLE(7, 2) NULL,
  `GW2_Conductivity` DOUBLE(7, 2) NULL,
  `GW2_Flow_cms` DOUBLE(7, 2) NULL,
  `GW2_DELGFieldNo` VARCHAR(50) NULL,
  PRIMARY KEY (`FieldMeasureID`),
  UNIQUE INDEX `FieldMeasureID` (`FieldMeasureID`),
  INDEX `AquaticActivityID` (`AquaticActivityID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblFishCount` (
  `FishCountID` INT(10) NOT NULL AUTO_INCREMENT,
  `AquaticActivityID` INT(10) NULL,
  `TempAquaticActivityID` INT(10) NULL,
  `MovementDirection` VARCHAR(4) NULL,
  `MovementTime` VARCHAR(10) NULL,
  `FishSpeciesCd` VARCHAR(3) NULL,
  `FishOrigin` VARCHAR(10) NULL,
  `FishAgeClass` VARCHAR(12) NULL,
  `RelativeSizeClass` VARCHAR(10) NULL,
  `FishAge` VARCHAR(5) NULL,
  `SexCd` VARCHAR(1) NULL,
  `NoFish` INT(10) NULL,
  `FishStatusCd` VARCHAR(4) NULL,
  `RPM` DOUBLE(15, 5) NULL,
  `RPM Left_Right` VARCHAR(16) NULL,
  PRIMARY KEY (`FishCountID`),
  INDEX `{06EA6C0C-673D-49A5-80FF-3F8553` (`FishSpeciesCd`),
  INDEX `{5D7B660D-0861-4E5F-A43C-FEA1F6` (`SexCd`),
  INDEX `{66BB9C3A-7285-4FDB-B4BC-DBCB50` (`AquaticActivityID`),
  INDEX `{CAEC13B9-5CC5-4B2A-A167-36394C` (`FishStatusCd`),
  INDEX `{E12AAD0E-8C73-403B-9564-76C09F` (`FishAgeClass`),
  INDEX `AquaticActivityID` (`TempAquaticActivityID`),
  INDEX `AquaticActivityID1` (`AquaticActivityID`),
  INDEX `FishCountID` (`FishCountID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblFishFacility` (
  `FishFacilityID` INT(10) NOT NULL,
  `AquaticSiteID` INT(10) NULL,
  `FishFacilityType` VARCHAR(20) NULL,
  `FishFacilityCategory` VARCHAR(20) NULL,
  `WaterBodyID` INT(10) NULL,
  `FishFacilityName` VARCHAR(50) NULL,
  `AgencyCd` VARCHAR(4) NULL,
  `YearsActive` VARCHAR(20) NULL,
  `ActiveInd` VARCHAR(15) NULL,
  PRIMARY KEY (`FishFacilityID`),
  INDEX `{62AE88DB-B6DA-461A-8EFD-79994C` (`AgencyCd`),
  INDEX `AquaticSiteID` (`AquaticSiteID`),
  INDEX `FishFacilityID` (`FishFacilityID`),
  INDEX `WaterBodyID` (`WaterBodyID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblFishMating` (
  `FishMatingID` INT(10) NOT NULL AUTO_INCREMENT,
  `FishMating` VARCHAR(150) NULL,
  PRIMARY KEY (`FishMatingID`),
  INDEX `Mating Code` (`FishMatingID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblFishMeasurement` (
  `FishSampleID` INT(10) NOT NULL AUTO_INCREMENT,
  `AquaticActivityID` INT(10) NULL,
  `TempAquaticActivityID` INT(10) NULL,
  `SweepNo` INT(10) NULL,
  `FishSpeciesCd` VARCHAR(2) NULL,
  `FishOrigin` VARCHAR(1) NULL,
  `FishAge` VARCHAR(255) NULL,
  `FishAgeClass` VARCHAR(20) NULL,
  `RelativeSizeClass` VARCHAR(6) NULL,
  `SexCd` VARCHAR(4) NULL,
  `Maturity` VARCHAR(50) NULL,
  `FishStatusCd` VARCHAR(25) NULL,
  `FishMortalityCauseCd` INT(10) NULL,
  `ForkLength_mm` DOUBLE(15, 5) NULL,
  `TotalLength_mm` DOUBLE(15, 5) NULL,
  `Weight_gm` DOUBLE(15, 5) NULL,
  `ObservedMarkCd` INT(10) NULL,
  `ObservedTagTypeCd` VARCHAR(255) NULL,
  `ObservedTagNo` VARCHAR(255) NULL,
  `AppliedMarkCd` INT(10) NULL,
  `AppliedTagTypeCd` VARCHAR(255) NULL,
  `AppliedTagDetails` VARCHAR(50) NULL,
  `AppliedTagNo` VARCHAR(255) NULL,
  `ScaleSampleInd` VARCHAR(1) NULL,
  `KFactor` VARCHAR(255) NULL,
  `Comments` VARCHAR(255) NULL,
  PRIMARY KEY (`FishSampleID`),
  INDEX `{3A73ACBD-5E01-4161-A005-936056` (`FishAgeClass`),
  INDEX `{5789DFE0-E15C-4411-B206-AB85F6` (`ObservedMarkCd`),
  INDEX `{78BF6931-900B-4BA0-9668-0F6ADF` (`FishStatusCd`),
  INDEX `{B3899285-6946-4B56-8F15-8CC930` (`FishMortalityCauseCd`),
  INDEX `{BAEC7ACC-1DA9-47D4-A524-136D1F` (`AppliedMarkCd`),
  INDEX `{C8F34BD0-92BF-465C-9970-616E6A` (`FishSpeciesCd`),
  INDEX `{F065211C-F778-44FD-9014-6CD26F` (`SexCd`),
  INDEX `AquaticActivityID` (`TempAquaticActivityID`),
  INDEX `AquaticActivityID1` (`AquaticActivityID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblFishStock` (
  `FishStockID` INT(10) NOT NULL,
  `FishSpeciesCd` VARCHAR(2) NULL,
  `WaterBodyID` INT(10) NULL,
  `FishStockName` VARCHAR(150) NULL,
  `WildStatus` VARCHAR(30) NULL,
  `RunSeason` VARCHAR(10) NULL,
  `TriploidInd` TINYINT(1) NOT NULL DEFAULT 0,
  `LandlockedInd` TINYINT(1) NOT NULL DEFAULT 0,
  `FishFacilityID` INT(10) NULL,
  PRIMARY KEY (`FishStockID`),
  INDEX `{9CC37BEE-D922-4454-8E9C-90F6EB` (`FishSpeciesCd`),
  INDEX `FishFacilityID` (`FishFacilityID`),
  INDEX `FishStockID` (`FishStockID`),
  INDEX `WaterBodyID` (`WaterBodyID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblFishTranslocation` (
  `FishTranslocationID` INT(10) NOT NULL AUTO_INCREMENT,
  `AquaticActivityID` INT(10) NULL,
  `TempAquaticActivityID` INT(10) NULL,
  `FishStockID` INT(10) NULL,
  `FishAgeClass` VARCHAR(6) NULL,
  `NoFish` DOUBLE(15, 5) NULL,
  `ForkLength_cm` DOUBLE(15, 5) NULL,
  `Weight_gm` DOUBLE(15, 5) NULL,
  `AppliedMarkCd` INT(10) NULL,
  `AppliedTagNo` VARCHAR(50) NULL,
  `Source` VARCHAR(50) NULL,
  PRIMARY KEY (`FishTranslocationID`),
  INDEX `{197AEA6C-6EDA-4CDD-928E-AC3D74` (`FishAgeClass`),
  INDEX `{3F66498F-954D-4260-B4DB-340DA6` (`FishStockID`),
  INDEX `{C1A7EB34-A8A5-481B-A17D-074E4F` (`AppliedMarkCd`),
  INDEX `AquaticActivityID` (`AquaticActivityID`),
  INDEX `FishStockID` (`FishStockID`),
  INDEX `FishTranslocationID` (`FishTranslocationID`),
  INDEX `OldAquaticActivityID` (`TempAquaticActivityID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblHabitatRestoration` (
  `AquaticActivityID` INT(10) NOT NULL,
  `TempAquaticActivityID` INT(10) NULL,
  `RestorationDesc` VARCHAR(150) NULL,
  PRIMARY KEY (`AquaticActivityID`),
  INDEX `{A405B266-7050-4183-B60D-3AFE5A` (`AquaticActivityID`),
  INDEX `AquaticActivityID` (`AquaticActivityID`),
  INDEX `OldAquaticActivityID` (`TempAquaticActivityID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblHabitatUnit` (
  `HabitatUnitID` DOUBLE(15, 5) NOT NULL,
  `AquaticActivityID` INT(10) NULL,
  `TempAquaticActivityID` INT(10) NULL,
  `RiverSystemID` SMALLINT(5) NULL,
  `WaterBodyID` DOUBLE(15, 5) NULL,
  `WaterBodyName` VARCHAR(40) NULL,
  `StartRouteMeas` DOUBLE(15, 5) NULL,
  `EndRouteMeas` DOUBLE(15, 5) NULL,
  `CalibratedLength_m` DOUBLE(15, 5) NULL,
  `StreamOrder` SMALLINT(5) NULL,
  `ReachNo` SMALLINT(5) NULL,
  `HabitatUnitNo` VARCHAR(3) NULL,
  `StreamTypeCd` VARCHAR(2) NULL,
  `ChannelCd` VARCHAR(1) NULL,
  `ChannelPosition` VARCHAR(1) NULL,
  `StreamLength_m` DOUBLE(15, 5) NULL,
  `WetWidth_m` DOUBLE(15, 5) NULL,
  `BankFullWidth_m` DOUBLE(15, 5) NULL,
  `Area_m2` DOUBLE(15, 5) NULL,
  `Bedrock` SMALLINT(5) NULL,
  `Boulder` SMALLINT(5) NULL,
  `Rock` SMALLINT(5) NULL,
  `Rubble` SMALLINT(5) NULL,
  `Gravel` SMALLINT(5) NULL,
  `Sand` SMALLINT(5) NULL,
  `Fines` SMALLINT(5) NULL,
  `TotalLgSubstrate` SMALLINT(5) NULL,
  `AveDepth_cm` SMALLINT(5) NULL,
  `UndercutBank_L` SMALLINT(5) NULL,
  `UndercutBank_R` SMALLINT(5) NULL,
  `OverhangingVeg_L` SMALLINT(5) NULL,
  `OverhangingVeg_R` SMALLINT(5) NULL,
  `WoodyDebrisLength_m` DOUBLE(15, 5) NULL,
  `WoodyDebrisLengthPer100m2` DOUBLE(15, 5) NULL,
  `WaterSourceCd` VARCHAR(1) NULL,
  `WaterFlow_cms` DOUBLE(15, 5) NULL,
  `AssmtTime` VARCHAR(5) NULL,
  `WaterTemp_C` DOUBLE(15, 5) NULL,
  `AirTemp_C` DOUBLE(15, 5) NULL,
  `EmbeddedCd` VARCHAR(1) NULL,
  `CommentCds` VARCHAR(150) NULL,
  `Shade` SMALLINT(5) NULL,
  `Bank_Bare` SMALLINT(5) NULL,
  `Bank_Grass` SMALLINT(5) NULL,
  `Bank_Shrubs` SMALLINT(5) NULL,
  `Bank_Trees` SMALLINT(5) NULL,
  `Bank_L_Stable` SMALLINT(5) NULL,
  `Bank_L_BarelyStable` SMALLINT(5) NULL,
  `Bank_L_Eroding` SMALLINT(5) NULL,
  `Bank_R_Stable` SMALLINT(5) NULL,
  `Bank_R_BarelyStable` SMALLINT(5) NULL,
  `Bank_R_Eroding` SMALLINT(5) NULL,
  `FieldNotes` VARCHAR(250) NULL,
  PRIMARY KEY (`HabitatUnitID`),
  INDEX `{2C20CD7A-D76A-4B79-9722-A2169A` (`ChannelCd`),
  INDEX `{4E89055D-2136-4D66-B94B-190547` (`EmbeddedCd`),
  INDEX `{77627C39-5B81-431D-8AFC-2A560E` (`StreamTypeCd`),
  INDEX `{AFB36345-F8C9-44B0-87E6-4C519B` (`AquaticActivityID`),
  INDEX `{B40FC300-BC5B-4B37-B35E-421B87` (`WaterSourceCd`),
  INDEX `{F8305F71-FA7B-4614-BD08-B115EB` (`RiverSystemID`),
  INDEX `AquaticActivityID` (`TempAquaticActivityID`),
  INDEX `AquaticActivityID1` (`AquaticActivityID`),
  INDEX `HABUNIT_ID` (`HabitatUnitID`),
  INDEX `RiverSystemID` (`RiverSystemID`),
  INDEX `WATER_ID` (`WaterBodyID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblHabitatUnitComment` (
  `AquaticActivityID` INT(10) NULL,
  `TempAquaticActivityID` INT(10) NULL,
  `HabitatUnitID` DOUBLE(15, 5) NULL,
  `CommentCd` VARCHAR(3) NULL,
  `Comment` VARCHAR(30) NULL,
  INDEX `{1D8D4C80-ED60-4F4D-AD66-AEFD1A` (`HabitatUnitID`),
  INDEX `{CE25D1D9-753C-4839-A68F-C3A029` (`CommentCd`),
  INDEX `AquaticActivityID` (`TempAquaticActivityID`),
  INDEX `AquaticActivityID1` (`AquaticActivityID`),
  INDEX `HABUNIT_ID` (`HabitatUnitID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblHabitatUnitWaterMeasurement` (
  `AquaticActivityID` INT(10) NULL,
  `TempAquaticActivityID` INT(10) NULL,
  `HabitatUnitID` DOUBLE(15, 5) NULL,
  `WaterSourceCd` VARCHAR(1) NULL,
  `AssmtTime` VARCHAR(5) NULL,
  `WaterTemp_C` DOUBLE(15, 5) NULL,
  `AirTemp_C` DOUBLE(15, 5) NULL,
  `WaterFlow_cms` DOUBLE(15, 5) NULL,
  `WaterFlow_gpm` DOUBLE(15, 5) NULL,
  `WaterFlow_lpm` DOUBLE(15, 5) NULL,
  INDEX `{597706DE-D7FA-4CD5-A07A-B86693` (`HabitatUnitID`),
  INDEX `{930FC3B8-C2A8-4C09-B400-AED987` (`WaterSourceCd`),
  INDEX `AquaticActivityID` (`TempAquaticActivityID`),
  INDEX `AquaticActivityID1` (`AquaticActivityID`),
  INDEX `HABUNIT_ID` (`HabitatUnitID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblLakeAttribute` (
  `WaterBodyID` INT(10) NOT NULL,
  `County` VARCHAR(20) NULL,
  `Parish` VARCHAR(30) NULL,
  `LakeClass` VARCHAR(15) NULL,
  `Area_m2` DOUBLE(15, 5) NULL,
  `Perimeter_m` DOUBLE(15, 5) NULL,
  `ShorelineCrown_Percent` INT(10) NULL,
  `ShorelinePrivate_Percent` INT(10) NULL,
  `Depth_Max` DOUBLE(15, 5) NULL,
  `Depth_Mean` DOUBLE(15, 5) NULL,
  `Depth_Percent_LT6m` SMALLINT(5) NULL,
  `Depth_Percent_LT3m` SMALLINT(5) NULL,
  `StratifiedInd` VARCHAR(2) NULL,
  `Volume_m3` DOUBLE(15, 5) NULL,
  `AcreFeet` DOUBLE(15, 5) NULL,
  `MEI` DOUBLE(15, 5) NULL,
  `PotentialProductivity` DOUBLE(15, 5) NULL,
  `WCHIndex` DOUBLE(15, 5) NULL,
  `SalmonIndex` DOUBLE(15, 5) NULL,
  `TogueIndex` DOUBLE(15, 5) NULL,
  `TotalProductivity` DOUBLE(15, 5) NULL,
  `ShorelineDev` DOUBLE(15, 5) NULL,
  PRIMARY KEY (`WaterBodyID`),
  UNIQUE INDEX `{4E408586-E3BB-430C-BCE6-FAB4A7` (`WaterBodyID`),
  INDEX `WATER_ID` (`WaterBodyID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblLakeSurveyDetail` (
  `AquaticActivityID` INT(10) NULL,
  `TempAquaticActivityID` INT(10) NULL,
  `DNRRegion` VARCHAR(1) NULL,
  `CountyCd` VARCHAR(2) NULL,
  `County` VARCHAR(20) NULL,
  `ParishCd` VARCHAR(3) NULL,
  `PARISH` VARCHAR(30) NULL,
  `AirTemp_F` SMALLINT(5) NULL,
  `Terrain_Flat` SMALLINT(5) NULL,
  `Terrain_Rolling` SMALLINT(5) NULL,
  `Terrain_Hilly` SMALLINT(5) NULL,
  `Terrain_Mountains` SMALLINT(5) NULL,
  `Forest_Softwood` SMALLINT(5) NULL,
  `Forest_Hardwood` SMALLINT(5) NULL,
  `Forest_Soft_Hard` SMALLINT(5) NULL,
  `Forest_Hard_Soft` SMALLINT(5) NULL,
  `ShoreUse_Cutover` SMALLINT(5) NULL,
  `ShoreUse_MatureTimber` SMALLINT(5) NULL,
  `ShoreUse_ImmatureTimber` SMALLINT(5) NULL,
  `ShoreUse_Residences` SMALLINT(5) NULL,
  `ShoreUse_Cottages` SMALLINT(5) NULL,
  `ShoreUse_Farms` SMALLINT(5) NULL,
  `ShoreUse_Wetlands` SMALLINT(5) NULL,
  `AquaticVeg_Submerged` SMALLINT(5) NULL,
  `AquaticVeg_Emergent` SMALLINT(5) NULL,
  `ShoreVeg_Sedge` SMALLINT(5) NULL,
  `ShoreVeg_Heath` SMALLINT(5) NULL,
  `ShoreVeg_Cedar` SMALLINT(5) NULL,
  `ShoreVeg_Alder` SMALLINT(5) NULL,
  `Substrate_Mud` SMALLINT(5) NULL,
  `Substrate_Sand` SMALLINT(5) NULL,
  `Substrate_Rubble` SMALLINT(5) NULL,
  `Substrate_Gravel` SMALLINT(5) NULL,
  `Substrate_Rock` SMALLINT(5) NULL,
  `Substrate_Boulders` SMALLINT(5) NULL,
  `Substrate_Bedrock` SMALLINT(5) NULL,
  `PublicAccess_Trail` SMALLINT(5) NULL,
  `PublicAccess_Car` SMALLINT(5) NULL,
  `PublicAccess_Jeep` SMALLINT(5) NULL,
  `PublicAccess_Boat` SMALLINT(5) NULL,
  `PrivateAccess_Trail` SMALLINT(5) NULL,
  `PrivateAccess_Car` SMALLINT(5) NULL,
  `PrivateAccess_Jeep` SMALLINT(5) NULL,
  `PrivateAccess_Boat` SMALLINT(5) NULL,
  `NoBoatLandings` SMALLINT(5) NULL,
  `ShoreOwnership_Crown` SMALLINT(5) NULL,
  `ShoreOwnership_Private` SMALLINT(5) NULL,
  `NoCamps` SMALLINT(5) NULL,
  `NoBeaches` SMALLINT(5) NULL,
  `WoodyDebris` VARCHAR(14) NULL,
  `ShorelineShape` VARCHAR(16) NULL,
  `SpawningPotential` VARCHAR(4) NULL,
  `SecchiDepth_ft` SMALLINT(5) NULL,
  `WaterColor` VARCHAR(14) NULL,
  `WaterChemInd` VARCHAR(1) NULL,
  `AnglingInfoInd` VARCHAR(1) NULL,
  INDEX `{5316EF9C-8A04-4E5D-9CB5-393792` (`AquaticActivityID`),
  INDEX `ActivityID` (`AquaticActivityID`),
  INDEX `oldAquaticActivityID` (`TempAquaticActivityID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblLakeSurveyFishSpecies` (
  `LakeSurveyFishID` INT(10) NOT NULL AUTO_INCREMENT,
  `AquaticActivityID` INT(10) NULL,
  `OldAssmtID` SMALLINT(5) NULL,
  `HoursFished` SMALLINT(5) NULL,
  `GearType` VARCHAR(20) NULL,
  `FishSpeciesCd` VARCHAR(2) NULL,
  `NoFish` SMALLINT(5) NULL,
  `Length_Min` DOUBLE(15, 5) NULL,
  `Length_Max` DOUBLE(15, 5) NULL,
  `PopulationStatus` VARCHAR(8) NULL,
  PRIMARY KEY (`LakeSurveyFishID`),
  INDEX `{83C4C015-3FED-4A6C-A4CA-11E735` (`AquaticActivityID`),
  INDEX `{AC5B557E-7BBC-48AF-A07C-926CB9` (`FishSpeciesCd`),
  INDEX `activityid` (`AquaticActivityID`),
  INDEX `ASSMT_ID` (`OldAssmtID`),
  INDEX `LakeSurveyFishID` (`LakeSurveyFishID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblLakeSurveyTribAssessment` (
  `LakeSurveyTribID` INT(10) NOT NULL AUTO_INCREMENT,
  `AquaticActivityID` INT(10) NULL,
  `OldAssmtID` SMALLINT(5) NULL,
  `TributaryName` VARCHAR(20) NULL,
  `SurveyLength_mi` DOUBLE(15, 5) NULL,
  `AveWidth_ft` SMALLINT(5) NULL,
  `WaterLevel` VARCHAR(8) NULL,
  `Silt` SMALLINT(5) NULL,
  `Sand` SMALLINT(5) NULL,
  `Gravel` SMALLINT(5) NULL,
  `Rubble` SMALLINT(5) NULL,
  `Rock` SMALLINT(5) NULL,
  `Boulder` SMALLINT(5) NULL,
  `Bedrock` SMALLINT(5) NULL,
  `NurseryLength_ft` SMALLINT(5) NULL,
  `NurseryWidth_ft` SMALLINT(5) NULL,
  `NurseryQuality` SMALLINT(5) NULL,
  `SpawningLength_ft` SMALLINT(5) NULL,
  `SpawningWidth_ft` SMALLINT(5) NULL,
  `SpawningQuality` SMALLINT(5) NULL,
  `NoPools_LT3ftDeep` SMALLINT(5) NULL,
  `NoPools_3to6ftDeep` SMALLINT(5) NULL,
  `NoPools_GT6ftDeep` SMALLINT(5) NULL,
  `ObstructionInd` VARCHAR(1) NULL,
  `ObstructionType` VARCHAR(10) NULL,
  `FishwayInd` VARCHAR(1) NULL,
  `VerticalJump` SMALLINT(5) NULL,
  `HorizontalJump` SMALLINT(5) NULL,
  PRIMARY KEY (`LakeSurveyTribID`),
  INDEX `{815C93E0-C509-47BE-939F-B306D3` (`AquaticActivityID`),
  INDEX `activityID` (`AquaticActivityID`),
  INDEX `ASSMT_ID` (`OldAssmtID`),
  INDEX `LakeSurveyTribID` (`LakeSurveyTribID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblLakeSurveyWaterMeasurement` (
  `LakeSurveyWaterMeasID` INT(10) NOT NULL AUTO_INCREMENT,
  `AquaticActivityID` INT(10) NULL,
  `OldAssmtID` SMALLINT(5) NULL,
  `AirTemp` SMALLINT(5) NULL,
  `SampleDepth` DOUBLE(15, 5) NULL,
  `WaterTemp_F` SMALLINT(5) NULL,
  `DissolvedO2` DOUBLE(15, 5) NULL,
  `O2Saturation` DOUBLE(15, 5) NULL,
  `pH` DOUBLE(15, 5) NULL,
  `PhenoAlkalinity` DOUBLE(15, 5) NULL,
  `MethylOrangeAlkalinity` DOUBLE(15, 5) NULL,
  `TotalHardness` DOUBLE(15, 5) NULL,
  `CO2` DOUBLE(15, 5) NULL,
  `FreeAcid` DOUBLE(15, 5) NULL,
  PRIMARY KEY (`LakeSurveyWaterMeasID`),
  INDEX `{FCA583A3-894E-448B-8E19-1E2110` (`AquaticActivityID`),
  INDEX `ACTIVITYID` (`AquaticActivityID`),
  INDEX `ASSMT_ID` (`OldAssmtID`),
  INDEX `FREE_ACID` (`FreeAcid`),
  INDEX `LakeSurveyWaterMeasID` (`LakeSurveyWaterMeasID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblLevel1Basin` (
  `Level1No` VARCHAR(2) NOT NULL,
  `Level1Name` VARCHAR(40) NULL,
  `OceanName` VARCHAR(20) NULL,
  `Area_km2` DOUBLE(15, 5) NULL,
  `Area_Percent` DOUBLE(15, 5) NULL,
  PRIMARY KEY (`Level1No`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblObservations` (
  `ObservationID` INT(10) NOT NULL AUTO_INCREMENT,
  `AquaticActivityID` INT(10) NULL,
  `OandMCd` INT(10) NULL,
  `OandM_Details` VARCHAR(150) NULL,
  `OandMValuesCd` INT(10) NULL,
  `FishPassageObstructionInd` TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ObservationID`),
  INDEX `AquaticActivityID` (`AquaticActivityID`),
  INDEX `EnvSurveyID` (`ObservationID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblOldHabitatSurvey` (
  `HabitatSurveyID` INT(10) NOT NULL AUTO_INCREMENT,
  `WaterBodyID` DOUBLE(15, 5) NULL,
  `AgencyCd` VARCHAR(4) NULL,
  `SectionNo` SMALLINT(5) NULL,
  `SectionDesc` VARCHAR(50) NULL,
  `StreamLength_m` DOUBLE(15, 5) NULL,
  `AveWidth_m` DOUBLE(15, 5) NULL,
  `Area_m2` DOUBLE(15, 5) NULL,
  `ProductiveArea` DOUBLE(15, 5) NULL,
  `NonProductiveArea_m2` DOUBLE(15, 5) NULL,
  `GoodArea_m2` DOUBLE(15, 5) NULL,
  `FairArea_m2` DOUBLE(15, 5) NULL,
  `PoorArea_m2` DOUBLE(15, 5) NULL,
  `FieldNotes` VARCHAR(150) NULL,
  PRIMARY KEY (`HabitatSurveyID`),
  INDEX `HabitatSurveyID` (`HabitatSurveyID`),
  INDEX `WATER_ID` (`WaterBodyID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblPhotos` (
  `PhotoID` INT(10) NOT NULL AUTO_INCREMENT,
  `AquaticActivityID` INT(10) NULL,
  `Path` VARCHAR(50) NULL,
  `FileName` VARCHAR(50) NULL,
  PRIMARY KEY (`PhotoID`),
  INDEX `AquaticActivityID` (`AquaticActivityID`),
  INDEX `PhotoID` (`PhotoID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblReconnaissanceResult` (
  `AquaticActivityID` INT(10) NOT NULL,
  `TempAquaticActivityID` INT(10) NULL,
  `StreamTypeCd` VARCHAR(2) NULL,
  `WetWidth_m` DOUBLE(15, 5) NULL,
  `BankFullWidth_m` DOUBLE(15, 5) NULL,
  `Bedrock` SMALLINT(5) NULL,
  `Boulder` SMALLINT(5) NULL,
  `Rock` SMALLINT(5) NULL,
  `Rubble` SMALLINT(5) NULL,
  `Gravel` SMALLINT(5) NULL,
  `Sand` SMALLINT(5) NULL,
  `Fines` SMALLINT(5) NULL,
  `EmbeddedCd` VARCHAR(1) NULL,
  `AssmtTime` VARCHAR(4) NULL,
  `AirTemp_C` DOUBLE(15, 5) NULL,
  `WaterTemp_C` DOUBLE(15, 5) NULL,
  `WaterFlow_cms` DOUBLE(15, 5) NULL,
  PRIMARY KEY (`AquaticActivityID`),
  INDEX `{A1DC03BD-AD41-48A5-BE14-D25FF1` (`StreamTypeCd`),
  INDEX `{D8682845-4751-4B5D-BC5F-C5F964` (`EmbeddedCd`),
  INDEX `AquaticActivityID` (`AquaticActivityID`),
  INDEX `oldAquaticActivityID` (`TempAquaticActivityID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblReddCount` (
  `AquaticActivityID` INT(10) NOT NULL,
  `TempAquaticActivityID` INT(10) NULL,
  `NoSmallRedds` DOUBLE(15, 5) NULL,
  `NoLargeRedds` DOUBLE(15, 5) NULL,
  `TotalRedds` DOUBLE(15, 5) NULL,
  `NoGrilse` DOUBLE(15, 5) NULL,
  `NoMSW` DOUBLE(15, 5) NULL,
  `TotalASalmon` DOUBLE(15, 5) NULL,
  `Comments` VARCHAR(150) NULL,
  PRIMARY KEY (`AquaticActivityID`),
  INDEX `{222C0077-C2AF-4260-A81C-E9A777` (`AquaticActivityID`),
  INDEX `AquaticActivityID` (`TempAquaticActivityID`),
  INDEX `AquaticActivityID1` (`AquaticActivityID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblRegulatedWater` (
  `RegulatedWaterID` INT(10) NOT NULL AUTO_INCREMENT,
  `WaterBodyID` INT(10) NULL,
  `WaterBodyName` VARCHAR(50) NULL,
  `RegulatedWaterName` VARCHAR(50) NULL,
  `RegulationType` VARCHAR(20) NULL,
  `RegulatedWaterCategory` VARCHAR(20) NULL,
  `RegulatedWaterType` VARCHAR(20) NULL,
  `SectionDes` VARCHAR(255) NULL,
  `IncludesTribuaryInd` VARCHAR(1) NULL,
  `StartDate` VARCHAR(10) NULL,
  `EndDate` VARCHAR(10) NULL,
  `StartDate2` VARCHAR(10) NULL,
  `EndDate2` VARCHAR(10) NULL,
  `StartYear` VARCHAR(10) NULL,
  `EndYear` VARCHAR(10) NULL,
  `ActiveInd` VARCHAR(1) NULL,
  `Robins Comments` VARCHAR(250) NULL,
  PRIMARY KEY (`RegulatedWaterID`),
  INDEX `ID` (`RegulatedWaterID`),
  INDEX `WaterBodyID` (`WaterBodyID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblRegulatedWaterStretch` (
  `RegWaterStretchID` INT(10) NOT NULL AUTO_INCREMENT,
  `RegulatedWaterID` INT(10) NULL,
  `RegulatedWaterName` VARCHAR(50) NULL,
  `RegulationType` VARCHAR(20) NULL,
  `RegulatedWaterCategory` VARCHAR(20) NULL,
  `RegulatedWaterType` VARCHAR(20) NULL,
  `SectionDesc` VARCHAR(255) NULL,
  `WaterBodyID` INT(10) NULL,
  `StartRouteMeas` DOUBLE(15, 5) NULL,
  `EndRouteMeas` DOUBLE(15, 5) NULL,
  `StreamLength_m` DOUBLE(15, 5) NULL,
  PRIMARY KEY (`RegWaterStretchID`),
  INDEX `{A1CB7636-57E5-40DC-994A-E5480B` (`WaterBodyID`),
  INDEX `{C115ED9E-8DC5-4E4E-9FD3-028E51` (`RegulatedWaterID`),
  INDEX `ID` (`RegWaterStretchID`),
  INDEX `RegWaterID` (`RegulatedWaterID`),
  INDEX `WaterBodyID` (`WaterBodyID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblRelatedAquaticActivities` (
  `RelatedAquaticActivitiesID` INT(10) NOT NULL AUTO_INCREMENT,
  `PrimaryAquaticActivityID` INT(10) NULL,
  `RelatedAquaticActivityID` INT(10) NULL,
  `oldPrimaryAquaticActivityID` INT(10) NULL,
  `oldRelatedAquaticActivityID` INT(10) NULL,
  PRIMARY KEY (`RelatedAquaticActivitiesID`),
  INDEX `AquaticActivityID` (`oldPrimaryAquaticActivityID`),
  INDEX `oldRelatedAquaticActivityID` (`oldRelatedAquaticActivityID`),
  INDEX `PrimaryAquaticActivityID` (`PrimaryAquaticActivityID`),
  INDEX `RelatedAquaticActivityID` (`RelatedAquaticActivitiesID`),
  INDEX `RelatedAquaticActivityID1` (`RelatedAquaticActivityID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblRiverSystem` (
  `RiverSystemID` SMALLINT(5) NOT NULL,
  `WaterBodyID` INT(10) NULL,
  `RiverSystemName` VARCHAR(40) NULL,
  `DrainageCd` VARCHAR(17) NULL,
  PRIMARY KEY (`RiverSystemID`),
  INDEX `RiverSystemID` (`RiverSystemID`),
  INDEX `WATER_ID` (`WaterBodyID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblSample` (
  `SampleID` INT(10) NOT NULL AUTO_INCREMENT,
  `AquaticActivityID` INT(10) NULL,
  `TempAquaticActivityID` INT(10) NULL,
  `LabNo` VARCHAR(10) NULL,
  `AgencySampleNo` VARCHAR(10) NULL,
  `SampleDepth_m` DOUBLE(7, 2) NULL,
  `WaterSourceType` VARCHAR(20) NULL,
  `SampleCollectionMethodCd` INT(10) NULL,
  `AnalyzedBy` VARCHAR(255) NULL,
  PRIMARY KEY (`SampleID`),
  INDEX `AquaticActivityID` (`AquaticActivityID`),
  INDEX `cdSampleCollectionMethodtblSamp` (`SampleCollectionMethodCd`),
  INDEX `tblAquaticActivitytblSample` (`AquaticActivityID`),
  INDEX `tblSampleWaterSourceType` (`WaterSourceType`),
  INDEX `TempAquaticActivityID` (`TempAquaticActivityID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblSatelliteRearing` (
  `AquaticActivityID` INT(10) NOT NULL,
  `TempAquaticActivityID` INT(10) NULL,
  `NoTanks` SMALLINT(5) NULL,
  `AgeClassReceived` VARCHAR(15) NULL,
  `NoReceived` INT(10) NULL,
  `DateStocked` VARCHAR(10) NULL,
  `NoStocked` INT(10) NULL,
  PRIMARY KEY (`AquaticActivityID`),
  INDEX `{63E3F53B-740C-4E97-82E7-710E46` (`AquaticActivityID`),
  INDEX `{B2F6C32C-EB8E-47D5-ABD1-9D0EB5` (`AgeClassReceived`),
  INDEX `AquaticActivityID` (`TempAquaticActivityID`),
  INDEX `AquaticActivityID1` (`AquaticActivityID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblSiteMeasurement` (
  `SiteMeasurementID` INT(10) NOT NULL AUTO_INCREMENT,
  `AquaticActivityID` INT(10) NULL,
  `OandMCd` INT(10) NULL,
  `OandM_Other` VARCHAR(20) NULL,
  `Bank` VARCHAR(10) NULL,
  `InstrumentCd` INT(10) NULL,
  `Measurement` DOUBLE(15, 5) NULL,
  `UnitofMeasureCd` INT(10) NULL,
  PRIMARY KEY (`SiteMeasurementID`),
  INDEX `AquaticActivityID` (`AquaticActivityID`),
  INDEX `SiteMeasurementID` (`SiteMeasurementID`),
  INDEX `tblAquaticActivitytblSiteMeasur` (`AquaticActivityID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblSpawners` (
  `AquaticActivityID` INT(10) NULL,
  `TempAquaticActivityID` INT(10) NULL,
  `SmallRedds` DOUBLE(15, 5) NULL,
  `LargeRedds` DOUBLE(15, 5) NULL,
  `TotalRedds` DOUBLE(15, 5) NULL,
  `NoGrilse` DOUBLE(15, 5) NULL,
  `NoMSW` DOUBLE(15, 5) NULL,
  `TotalASalmon` DOUBLE(15, 5) NULL,
  `Comments` VARCHAR(150) NULL,
  INDEX `AquaticActivityID1` (`TempAquaticActivityID`),
  INDEX `AquaticActivityID2` (`AquaticActivityID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblSportfishingAnglingLease` (
  `SportfishingID` INT(10) NOT NULL AUTO_INCREMENT,
  `RegulatedWaterID` INT(10) NULL,
  `LeaseNo` SMALLINT(5) NULL,
  `Year` VARCHAR(4) NULL,
  `TB_TS_RodDay` DOUBLE(15, 5) NULL,
  `TB_TS_RodHours` INT(10) NULL,
  `TB_Gr_Harvest` DOUBLE(15, 5) NULL,
  `TB_Gr_Release` DOUBLE(15, 5) NULL,
  `TB_Gr_Total` DOUBLE(15, 5) NULL,
  `TB_MSW_Harvest` DOUBLE(15, 5) NULL,
  `TB_MSW_Release` DOUBLE(15, 5) NULL,
  `TB_MSW_Total` DOUBLE(15, 5) NULL,
  `TB_AS_Harvest` DOUBLE(15, 5) NULL,
  `TB_AS_Release` DOUBLE(15, 5) NULL,
  `TB_AS_Total` DOUBLE(15, 5) NULL,
  `TB_CPU_Grilse` DOUBLE(15, 5) NULL,
  `TB_CPU_MSW` DOUBLE(15, 5) NULL,
  `TB_CPU_Total` DOUBLE(15, 5) NULL,
  `TS_BT_RodDay` DOUBLE(15, 5) NULL,
  `TS_BT_Harvest` DOUBLE(15, 5) NULL,
  `TS_BT_Release` DOUBLE(15, 5) NULL,
  `TS_BT_Total` DOUBLE(15, 5) NULL,
  `TS_CPU_BrookTrout` DOUBLE(15, 5) NULL,
  PRIMARY KEY (`SportfishingID`),
  INDEX `{30865C15-4322-4026-86DB-C859C8` (`RegulatedWaterID`),
  INDEX `LEASE_ID` (`LeaseNo`),
  INDEX `RegulatedWaterID` (`RegulatedWaterID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblSportfishingAtlanticSalmon` (
  `SportfishingID` INT(10) NOT NULL AUTO_INCREMENT,
  `WaterBodyID` INT(10) NULL,
  `WaterBodyName` VARCHAR(55) NULL,
  `DrainageCd` VARCHAR(17) NULL,
  `Year` VARCHAR(4) NULL,
  `KT_AS_RodDay` DOUBLE(15, 5) NULL,
  `KT_Gr_Harvest` DOUBLE(15, 5) NULL,
  `KT_Gr_Release` DOUBLE(15, 5) NULL,
  `KT_Gr_Total` DOUBLE(15, 5) NULL,
  `KT_MSW_Harvest` DOUBLE(15, 5) NULL,
  `KT_MSW_Release` DOUBLE(15, 5) NULL,
  `KT_MSW_Total` DOUBLE(15, 5) NULL,
  `KT_AS_Harvest` DOUBLE(15, 5) NULL,
  `KT_AS_Release` DOUBLE(15, 5) NULL,
  `KT_AS_Total` DOUBLE(15, 5) NULL,
  `KT_CPU_Grilse` DOUBLE(15, 5) NULL,
  `KT_CPU_MSW` DOUBLE(15, 5) NULL,
  `KT_CPU_Total` DOUBLE(15, 5) NULL,
  `KT_CPA_Lwr` DOUBLE(15, 5) NULL,
  `KT_CPA_Mean` DOUBLE(15, 5) NULL,
  `KT_CPA_Upr` DOUBLE(15, 5) NULL,
  `KT_CPA_CV` DOUBLE(15, 5) NULL,
  `TB_AS_RodDay` DOUBLE(15, 5) NULL,
  `TB_Gr_Harvest` DOUBLE(15, 5) NULL,
  `TB_Gr_Release` DOUBLE(15, 5) NULL,
  `TB_Gr_Total` DOUBLE(15, 5) NULL,
  `TB_MSW_Harvest` DOUBLE(15, 5) NULL,
  `TB_MSW_Release` DOUBLE(15, 5) NULL,
  `TB_MSW_Total` DOUBLE(15, 5) NULL,
  `TB_AS_Harvest` DOUBLE(15, 5) NULL,
  `TB_AS_Release` DOUBLE(15, 5) NULL,
  `TB_AS_Total` DOUBLE(15, 5) NULL,
  `TB_CPU_Grilse` DOUBLE(15, 5) NULL,
  `TB_CPU_MSW` DOUBLE(15, 5) NULL,
  `TB_CPU_Total` DOUBLE(15, 5) NULL,
  `TB_CPA_Lwr` DOUBLE(15, 5) NULL,
  `TB_CPA_Mean` DOUBLE(15, 5) NULL,
  `TB_CPA_Upr` DOUBLE(15, 5) NULL,
  `TB_CPA_CV` DOUBLE(15, 5) NULL,
  `EB_AS_RodDay` DOUBLE(15, 5) NULL,
  `EB_Gr_Harvest` DOUBLE(15, 5) NULL,
  `EB_Gr_Release` DOUBLE(15, 5) NULL,
  `EB_Gr_Total` DOUBLE(15, 5) NULL,
  `EB_MSW_Harvest` DOUBLE(15, 5) NULL,
  `EB_MSW_Release` DOUBLE(15, 5) NULL,
  `EB_MSW_Total` DOUBLE(15, 5) NULL,
  `EB_AS_Harvest` DOUBLE(15, 5) NULL,
  `EB_AS_Release` DOUBLE(15, 5) NULL,
  `EB_AS_Total` DOUBLE(15, 5) NULL,
  `EB_CPU_Grilse` DOUBLE(15, 5) NULL,
  `EB_CPU_MSW` DOUBLE(15, 5) NULL,
  `EB_CPU_Total` DOUBLE(15, 5) NULL,
  `LB_AS_RodDay` DOUBLE(15, 5) NULL,
  `LB_Gr_Harvest` DOUBLE(15, 5) NULL,
  `LB_Gr_Release` DOUBLE(15, 5) NULL,
  `LB_Gr_Total` DOUBLE(15, 5) NULL,
  `LB_MSW_Harvest` DOUBLE(15, 5) NULL,
  `LB_MSW_Release` DOUBLE(15, 5) NULL,
  `LB_MSW_Total` DOUBLE(15, 5) NULL,
  `LB_AS_Harvest` DOUBLE(15, 5) NULL,
  `LB_AS_Release` DOUBLE(15, 5) NULL,
  `LB_AS_Total` DOUBLE(15, 5) NULL,
  `LB_CPU_Grilse` DOUBLE(15, 5) NULL,
  `LB_CPU_MSW` DOUBLE(15, 5) NULL,
  `LB_CPU_Total` DOUBLE(15, 5) NULL,
  `TS_AS_RodDay` DOUBLE(15, 5) NULL,
  `TS_Gr_Harvest` DOUBLE(15, 5) NULL,
  `TS_Gr_Release` DOUBLE(15, 5) NULL,
  `TS_Gr_Total` DOUBLE(15, 5) NULL,
  `TS_MSW_Harvest` DOUBLE(15, 5) NULL,
  `TS_MSW_Release` DOUBLE(15, 5) NULL,
  `TS_MSW_Total` DOUBLE(15, 5) NULL,
  `TS_AS_Harvest` DOUBLE(15, 5) NULL,
  `TS_AS_Release` DOUBLE(15, 5) NULL,
  `TS_AS_Total` DOUBLE(15, 5) NULL,
  `TS_CPU_Grilse` DOUBLE(15, 5) NULL,
  `TS_CPU_MSW` DOUBLE(15, 5) NULL,
  `TS_CPU_Total` DOUBLE(15, 5) NULL,
  PRIMARY KEY (`SportfishingID`),
  INDEX `{B2264753-0653-48B6-93B6-759023` (`WaterBodyID`),
  INDEX `SportfishingID` (`SportfishingID`),
  INDEX `WATER_ID` (`WaterBodyID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblSportfishingCrownReserve` (
  `SportfishingID` INT(10) NOT NULL AUTO_INCREMENT,
  `RegulatedWaterID` INT(10) NULL,
  `Year` VARCHAR(4) NULL,
  `TB_TS_RodDay` DOUBLE(15, 5) NULL,
  `TB_Gr_Harvest` DOUBLE(15, 5) NULL,
  `TB_Gr_Release` DOUBLE(15, 5) NULL,
  `TB_Gr_Total` DOUBLE(15, 5) NULL,
  `TB_MSW_Harvest` DOUBLE(15, 5) NULL,
  `TB_MSW_Release` DOUBLE(15, 5) NULL,
  `TB_MSW_Total` DOUBLE(15, 5) NULL,
  `TB_AS_Harvest` DOUBLE(15, 5) NULL,
  `TB_AS_Release` DOUBLE(15, 5) NULL,
  `TB_AS_Total` DOUBLE(15, 5) NULL,
  `TB_CPU_Grilse` DOUBLE(15, 5) NULL,
  `TB_CPU_MSW` DOUBLE(15, 5) NULL,
  `TB_CPU_Total` DOUBLE(15, 5) NULL,
  `TS_BT_Harvest` DOUBLE(15, 5) NULL,
  `TS_BT_Release` DOUBLE(15, 5) NULL,
  `TS_BT_Total` DOUBLE(15, 5) NULL,
  PRIMARY KEY (`SportfishingID`),
  INDEX `{771658EA-10AB-4276-AE7C-A4A7E0` (`RegulatedWaterID`),
  INDEX `RegulatedWaterID` (`RegulatedWaterID`),
  INDEX `SportfishingID` (`SportfishingID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblStockedFish` (
  `FishStockingID` INT(10) NOT NULL AUTO_INCREMENT,
  `siteuseid` INT(10) NULL,
  `AquaticActivityID` INT(10) NULL,
  `TempAquaticActivityID` INT(10) NULL,
  `FishSpeciesCd` VARCHAR(2) NULL,
  `FishStockID` INT(10) NULL,
  `OtherStock` VARCHAR(50) NULL,
  `FishMatingID` INT(10) NULL,
  `FishStrainCd` INT(10) NULL,
  `BroodstockInd` TINYINT(1) NOT NULL DEFAULT 0,
  `FishAge` VARCHAR(10) NULL,
  `AgeUnitOfMeasure` VARCHAR(10) NULL,
  `FishAgeClass` VARCHAR(20) NULL,
  `NoFish` INT(10) NULL,
  `FishFacilityID` INT(10) NULL,
  `OtherFishFacility` VARCHAR(50) NULL,
  `FishTankNo` VARCHAR(2) NULL,
  `SatelliteRearedInd` TINYINT(1) NOT NULL DEFAULT 0,
  `AveLength_cm` DOUBLE(15, 5) NULL,
  `LengthRange_cm` VARCHAR(20) NULL,
  `FishLengthType` VARCHAR(10) NULL,
  `AveWeight_gm` DOUBLE(15, 5) NULL,
  `WeightRange_gm` VARCHAR(20) NULL,
  `NoFishMeasured` INT(10) NULL,
  `AppliedMarkCd` INT(10) NULL,
  `Source` VARCHAR(50) NULL,
  PRIMARY KEY (`FishStockingID`),
  INDEX `{42C7EB4F-0D16-4C9E-B72B-E3FAFE` (`FishStockID`),
  INDEX `{4664ED76-C4C5-4F01-94C2-787706` (`FishMatingID`),
  INDEX `{69365FA7-DC11-4323-8B3A-9B41CC` (`FishSpeciesCd`),
  INDEX `{98DE86FF-08D4-4803-B4A0-6BBE0E` (`AppliedMarkCd`),
  INDEX `{AA01333A-8722-46C3-8FD4-2BF486` (`FishFacilityID`),
  INDEX `{BC3A6A6A-7068-4DFD-8F21-E0E9B8` (`FishAgeClass`),
  INDEX `{DA7ACC03-F95D-442C-934E-76D801` (`AquaticActivityID`),
  INDEX `AquaticActivityID` (`TempAquaticActivityID`),
  INDEX `AquaticActivityID1` (`AquaticActivityID`),
  INDEX `FishMatingID` (`FishMatingID`),
  INDEX `FishRearingFacilID` (`FishFacilityID`),
  INDEX `FishStockID` (`FishStockID`),
  INDEX `FishStockingID` (`FishStockingID`),
  INDEX `siteuseid` (`siteuseid`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblStreamAttribute` (
  `WaterBodyID` INT(10) NOT NULL,
  `StreamLength_km` DOUBLE(15, 5) NULL,
  `HighestOrder` SMALLINT(5) NULL,
  `IntermittentInd` VARCHAR(1) NULL,
  `TidalInd` VARCHAR(1) NULL,
  PRIMARY KEY (`WaterBodyID`),
  UNIQUE INDEX `{A520FBFB-F9B2-44B6-99D7-0C8E1B` (`WaterBodyID`),
  INDEX `WATER_ID` (`WaterBodyID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblVibertBoxAnalysis` (
  `AquaticActivityID` INT(10) NULL,
  `TempAquaticActivityID` INT(10) NULL,
  `LocationDesc` VARCHAR(20) NULL,
  `LidDepth_cm` DOUBLE(15, 5) NULL,
  `WetWeight_Initial_gm` DOUBLE(15, 5) NULL,
  `WetWeight_Final_gm` DOUBLE(15, 5) NULL,
  `WetWeight_Net_gm` DOUBLE(15, 5) NULL,
  `WetWeight_Fines_Percent` DOUBLE(15, 5) NULL,
  `DryWeight_Total_gm` DOUBLE(15, 5) NULL,
  `DrytWeight_Box_Rocks_gm` DOUBLE(15, 5) NULL,
  `DryWeight_Box_Rocks_Percent` DOUBLE(15, 5) NULL,
  `DryWeight_FineGravel_gm` DOUBLE(15, 5) NULL,
  `DryWeight_fineGravel_Percent` DOUBLE(15, 5) NULL,
  `DryWeight_Sand_gm` DOUBLE(15, 5) NULL,
  `DryWeight_Sand_Percent` DOUBLE(15, 5) NULL,
  `DryWeight_Fines_gm` DOUBLE(15, 5) NULL,
  `DryWeight_Fines_Percent` DOUBLE(15, 5) NULL,
  `Comments` VARCHAR(150) NULL,
  INDEX `AquaticActivityID` (`AquaticActivityID`),
  INDEX `oldAquaticActivityID` (`TempAquaticActivityID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblWaterBody` (
  `WaterBodyID` INT(10) NOT NULL AUTO_INCREMENT,
  `DrainageCd` VARCHAR(17) NULL,
  `WaterBodyTypeCd` VARCHAR(4) NULL,
  `WaterBodyName` VARCHAR(55) NULL,
  `WaterBodyName_Abrev` VARCHAR(40) NULL,
  `WaterBodyName_Alt` VARCHAR(40) NULL,
  `WaterBodyComplexID` SMALLINT(5) NULL,
  `Surveyed_Ind` VARCHAR(1) NULL,
  `FlowsIntoWaterBodyID` DOUBLE(15, 5) NULL,
  `FlowsIntoWaterBodyName` VARCHAR(40) NULL,
  `FlowIntoDrainageCd` VARCHAR(17) NULL,
  `DateEntered` DATETIME NULL,
  `DateModified` DATETIME NULL,
  PRIMARY KEY (`WaterBodyID`),
  INDEX `{267293E5-26E7-418B-9AFA-318DAE` (`WaterBodyComplexID`),
  INDEX `CMPLX_ID` (`WaterBodyComplexID`),
  INDEX `DR_CODE` (`DrainageCd`),
  INDEX `FLOW_ID` (`FlowsIntoWaterBodyID`),
  INDEX `WATER_ID` (`WaterBodyID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblWaterBodyComplex` (
  `WaterBodyComplexID` SMALLINT(5) NOT NULL,
  `WaterBodyComplexName` VARCHAR(55) NULL,
  `WaterBodyComplexType` VARCHAR(4) NULL,
  `DrainageCd` VARCHAR(17) NULL,
  PRIMARY KEY (`WaterBodyComplexID`),
  INDEX `CMPLX_ID` (`WaterBodyComplexID`),
  INDEX `tblWaterBodyComplexesDrainageCd` (`DrainageCd`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblWaterChemistryAnalysis` (
  `AquaticActivityID` INT(10) NULL,
  `TempAquaticActivityID` INT(10) NULL,
  `DOE_Program` VARCHAR(14) NULL,
  `DOE_ProjectNo` VARCHAR(10) NULL,
  `DOE_StationNo` VARCHAR(15) NULL,
  `DOE_LabNo` VARCHAR(8) NULL,
  `DOE_FieldNo` VARCHAR(11) NULL,
  `SecchiDepth_m` DOUBLE(15, 5) NULL,
  `SampleDepth_m` DOUBLE(15, 5) NULL,
  `WaterTemp_C` DOUBLE(15, 5) NULL,
  `DO` DOUBLE(15, 5) NULL,
  `TOXIC_UNIT` DOUBLE(15, 5) NULL,
  `L_HARD` VARCHAR(1) NULL,
  `HARD` DOUBLE(15, 5) NULL,
  `NO3` DOUBLE(15, 5) NULL,
  `L_AL_X` VARCHAR(1) NULL,
  `AL_X` DOUBLE(15, 5) NULL,
  `L_AL_XGF` VARCHAR(1) NULL,
  `AL_XGF` DOUBLE(15, 5) NULL,
  `L_ALK_G` VARCHAR(1) NULL,
  `ALK_G` DOUBLE(15, 5) NULL,
  `L_ALK_P` VARCHAR(1) NULL,
  `ALK_P` DOUBLE(15, 5) NULL,
  `L_ALK_T` VARCHAR(1) NULL,
  `ALK_T` DOUBLE(15, 5) NULL,
  `L_AS_XGF` VARCHAR(1) NULL,
  `AS_XGF` DOUBLE(15, 5) NULL,
  `L_BA_X` VARCHAR(1) NULL,
  `BA_X` DOUBLE(15, 5) NULL,
  `L_B_X` VARCHAR(1) NULL,
  `B_X` DOUBLE(15, 5) NULL,
  `L_BR` VARCHAR(1) NULL,
  `BR` DOUBLE(15, 5) NULL,
  `L_CA_D` VARCHAR(1) NULL,
  `CA_D` DOUBLE(15, 5) NULL,
  `L_CD_XGF` VARCHAR(1) NULL,
  `CD_XGF` DOUBLE(15, 5) NULL,
  `L_CHL_A` VARCHAR(1) NULL,
  `CHL_A` DOUBLE(15, 5) NULL,
  `L_CL` VARCHAR(1) NULL,
  `CL` DOUBLE(15, 5) NULL,
  `L_CL_IC` VARCHAR(1) NULL,
  `CL_IC` DOUBLE(15, 5) NULL,
  `L_CLRA` VARCHAR(1) NULL,
  `CLRA` DOUBLE(15, 5) NULL,
  `L_CO_X` VARCHAR(1) NULL,
  `CO_X` DOUBLE(15, 5) NULL,
  `L_COND` VARCHAR(1) NULL,
  `COND` DOUBLE(15, 5) NULL,
  `COND2` DOUBLE(15, 5) NULL,
  `L_CR_X` VARCHAR(1) NULL,
  `CR_X` DOUBLE(15, 5) NULL,
  `L_CR_XGF` VARCHAR(1) NULL,
  `CR_XGF` DOUBLE(15, 5) NULL,
  `L_CU_X` VARCHAR(1) NULL,
  `CU_X` DOUBLE(15, 5) NULL,
  `L_CU_XGF` VARCHAR(1) NULL,
  `CU_XGF` DOUBLE(15, 5) NULL,
  `L_DOC` VARCHAR(1) NULL,
  `DOC` DOUBLE(15, 5) NULL,
  `L_F` VARCHAR(1) NULL,
  `F` DOUBLE(15, 5) NULL,
  `L_FE_X` VARCHAR(1) NULL,
  `FE_X` DOUBLE(15, 5) NULL,
  `L_HG_T` VARCHAR(1) NULL,
  `HG_T` DOUBLE(15, 5) NULL,
  `L_K` VARCHAR(1) NULL,
  `K` DOUBLE(15, 5) NULL,
  `L_MG_D` VARCHAR(1) NULL,
  `MG_D` DOUBLE(15, 5) NULL,
  `L_MN_X` VARCHAR(1) NULL,
  `MN_X` DOUBLE(15, 5) NULL,
  `L_NA` VARCHAR(1) NULL,
  `NA` DOUBLE(15, 5) NULL,
  `L_NH3T` VARCHAR(1) NULL,
  `NH3T` DOUBLE(15, 5) NULL,
  `L_NI_X` VARCHAR(1) NULL,
  `NI_X` DOUBLE(15, 5) NULL,
  `L_NO2D` VARCHAR(1) NULL,
  `NO2D` DOUBLE(15, 5) NULL,
  `L_NOX` VARCHAR(1) NULL,
  `NOX` DOUBLE(15, 5) NULL,
  `L_PB_XGF` VARCHAR(1) NULL,
  `PB_XGF` DOUBLE(15, 5) NULL,
  `L_PH` VARCHAR(1) NULL,
  `PH` DOUBLE(15, 5) NULL,
  `L_PH_GAL` VARCHAR(1) NULL,
  `PH_GAL` DOUBLE(15, 5) NULL,
  `L_SB_XGF` VARCHAR(1) NULL,
  `SB_XGF` DOUBLE(15, 5) NULL,
  `L_SE_XGF` VARCHAR(1) NULL,
  `SE_XGF` DOUBLE(15, 5) NULL,
  `SILICA` DOUBLE(15, 5) NULL,
  `L_SO4` VARCHAR(1) NULL,
  `SO4` DOUBLE(15, 5) NULL,
  `L_SO4_IC` VARCHAR(1) NULL,
  `SO4_IC` DOUBLE(15, 5) NULL,
  `L_SS` VARCHAR(1) NULL,
  `SS` DOUBLE(15, 5) NULL,
  `L_TDS` VARCHAR(1) NULL,
  `TDS` DOUBLE(15, 5) NULL,
  `L_TKN` VARCHAR(1) NULL,
  `TKN` DOUBLE(15, 5) NULL,
  `L_TL_XGF` VARCHAR(1) NULL,
  `TL_XGF` DOUBLE(15, 5) NULL,
  `L_TOC` VARCHAR(1) NULL,
  `TOC` DOUBLE(15, 5) NULL,
  `L_TP_L` VARCHAR(1) NULL,
  `TP_L` DOUBLE(15, 5) NULL,
  `L_TURB` VARCHAR(1) NULL,
  `TURB` DOUBLE(15, 5) NULL,
  `L_ZN_X` VARCHAR(1) NULL,
  `ZN_X` DOUBLE(15, 5) NULL,
  `L_ZN_XGF` VARCHAR(1) NULL,
  `ZN_XGF` DOUBLE(15, 5) NULL,
  `L_O_PHOS` VARCHAR(1) NULL,
  `O_PHOS` DOUBLE(15, 5) NULL,
  `BICARB` DOUBLE(15, 5) NULL,
  `CARB` DOUBLE(15, 5) NULL,
  `SAT_PH` DOUBLE(15, 5) NULL,
  `SAT_NDX` DOUBLE(15, 5) NULL,
  INDEX `{A84E8104-E838-4C00-8C7A-E4A3D7` (`AquaticActivityID`),
  INDEX `AquaticActivityID` (`TempAquaticActivityID`),
  INDEX `AquaticActivityID1` (`AquaticActivityID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblWaterMeasurement` (
  `WaterMeasurementID` INT(10) NOT NULL AUTO_INCREMENT,
  `AquaticActivityID` INT(10) NULL,
  `TempAquaticActivityID` INT(10) NULL,
  `TempDataID` INT(10) NULL,
  `TemperatureLoggerID` INT(10) NULL,
  `HabitatUnitID` INT(10) NULL,
  `SampleID` INT(10) NULL,
  `WaterSourceCd` VARCHAR(50) NULL,
  `WaterDepth_m` DOUBLE(7, 2) NULL,
  `TimeofDay` VARCHAR(5) NULL,
  `OandMCd` INT(10) NULL,
  `InstrumentCd` INT(10) NULL,
  `Measurement` DOUBLE(7, 2) NULL,
  `UnitofMeasureCd` INT(10) NULL,
  `QualifierCd` VARCHAR(20) NULL,
  `Comment` VARCHAR(255) NULL,
  PRIMARY KEY (`WaterMeasurementID`),
  INDEX `AquaticActivityID` (`TempAquaticActivityID`),
  INDEX `AquaticActivityID1` (`AquaticActivityID`),
  INDEX `cdInstrumenttblWaterMeasurement` (`InstrumentCd`),
  INDEX `cdOandMtblWaterMeasurement` (`OandMCd`),
  INDEX `cdUnitofMeasuretblWaterMeasurem` (`UnitofMeasureCd`),
  INDEX `cdWaterSourcetblWaterMeasurement` (`WaterSourceCd`),
  INDEX `SampleID` (`SampleID`),
  INDEX `tblAquaticActivitytblWaterMeasu` (`AquaticActivityID`),
  INDEX `tblWaterMeasurementQualifierCd` (`QualifierCd`),
  INDEX `TempDataID` (`TempDataID`),
  INDEX `TemperatureLoggerID` (`TemperatureLoggerID`),
  INDEX `WaterMeasurementID` (`WaterMeasurementID`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE TABLE `tblWaterTemperatureLoggerDetails` (
  `TemperatureLoggerID` INT(10) NOT NULL AUTO_INCREMENT,
  `AquaticActivityID` INT(10) NULL,
  `LoggerNo` VARCHAR(20) NULL,
  `BrandName` VARCHAR(30) NULL,
  `Model` VARCHAR(20) NULL,
  `Resolution` VARCHAR(20) NULL,
  `Accuracy` VARCHAR(20) NULL,
  `TempRange_From` INT(10) NULL,
  `TempRange_To` INT(10) NULL,
  `DataFileName` VARCHAR(75) NULL,
  `InstallationDate` VARCHAR(10) NULL,
  `RemovalDate` VARCHAR(10) NULL,
  `RecordingStartDate` VARCHAR(10) NULL,
  `RecordingEndDate` VARCHAR(10) NULL,
  `OutofWaterReadingsOccurred` TINYINT(1) NOT NULL DEFAULT 0,
  `OutofWaterReadingsRemoved` TINYINT(1) NOT NULL DEFAULT 0,
  `DistanceFromLeftBank_m` INT(10) NULL,
  `DistanceFromRightBank_m` INT(10) NULL,
  `WaterDepth_cm` INT(10) NULL,
  `SampleInterval_min` DOUBLE(7, 2) NULL,
  `Install_WaterTemp_C` DOUBLE(7, 2) NULL,
  `Install_AirTemp_C` DOUBLE(7, 2) NULL,
  `Install_TimeofDay` VARCHAR(5) NULL,
  `Removal_WaterTemp_C` DOUBLE(7, 2) NULL,
  `Removal_AirTemp_C` DOUBLE(7, 2) NULL,
  `Removal_TimeofDay` VARCHAR(5) NULL,
  `WaterLevel_Install` VARCHAR(10) NULL,
  `WaterLevel_Removal` VARCHAR(10) NULL,
  `DateEntered` DATETIME NULL,
  `IncorporatedInd` TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`TemperatureLoggerID`),
  UNIQUE INDEX `TemperatureLoggerID` (`TemperatureLoggerID`),
  INDEX `AquaticActivityID` (`AquaticActivityID`),
  INDEX `LoggerID` (`LoggerNo`)
)
ENGINE = INNODB
CHARACTER SET utf8 COLLATE utf8_general_ci;

SET FOREIGN_KEY_CHECKS = 1;
